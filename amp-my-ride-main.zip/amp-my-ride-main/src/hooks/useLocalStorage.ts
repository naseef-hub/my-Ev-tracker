import { useState, useEffect, useCallback, useRef } from 'react';

const LOCAL_STORAGE_EVENT = 'ev-local-storage-change';

type LocalStorageChangeDetail = {
  key: string;
  value: unknown;
};

export function useLocalStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch {
      return initialValue;
    }
  });

  const valueRef = useRef(storedValue);
  valueRef.current = storedValue;

  const setValue = useCallback((value: T | ((val: T) => T)) => {
    const valueToStore = value instanceof Function ? value(valueRef.current) : value;
    valueRef.current = valueToStore;
    setStoredValue(valueToStore);
    try {
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch {
      // Ignore quota/serialization failures.
    }
    window.dispatchEvent(new CustomEvent<LocalStorageChangeDetail>(LOCAL_STORAGE_EVENT, {
      detail: { key, value: valueToStore },
    }));
  }, [key]);


  useEffect(() => {
    const handleLocalChange = (event: Event) => {
      const detail = (event as CustomEvent<LocalStorageChangeDetail>).detail;
      if (detail?.key === key) setStoredValue(detail.value as T);
    };

    const handleStorageChange = (event: StorageEvent) => {
      if (event.key !== key || event.newValue === null) return;
      try {
        setStoredValue(JSON.parse(event.newValue) as T);
      } catch {
        // Keep the current value if another tab writes invalid data.
      }
    };

    window.addEventListener(LOCAL_STORAGE_EVENT, handleLocalChange);
    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener(LOCAL_STORAGE_EVENT, handleLocalChange);
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [key]);

  return [storedValue, setValue] as const;
}
