import { useLocalStorage } from './useLocalStorage';
import { Vehicle, ChargingSession, Settings, StationRate, Trip, DEFAULT_SETTINGS } from '@/types';

export function useVehicles() {
  const [vehicles, setVehicles] = useLocalStorage<Vehicle[]>('ev-vehicles', []);

  const addVehicle = (vehicle: Omit<Vehicle, 'id' | 'createdAt'>) => {
    const newVehicle: Vehicle = {
      ...vehicle,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
    setVehicles(prev => [...prev, newVehicle]);
    return newVehicle;
  };

  const updateVehicle = (id: string, data: Partial<Vehicle>) => {
    setVehicles(prev => prev.map(v => v.id === id ? { ...v, ...data } : v));
  };

  const deleteVehicle = (id: string) => {
    setVehicles(prev => prev.filter(v => v.id !== id));
  };

  return { vehicles, addVehicle, updateVehicle, deleteVehicle };
}

export function useSessions() {
  const [sessions, setSessions] = useLocalStorage<ChargingSession[]>('ev-sessions', []);

  const addSession = (session: Omit<ChargingSession, 'id' | 'createdAt'>) => {
    const newSession: ChargingSession = {
      ...session,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
    setSessions(prev => [...prev, newSession]);
    return newSession;
  };

  const updateSession = (id: string, data: Partial<ChargingSession>) => {
    setSessions(prev => prev.map(s => s.id === id ? { ...s, ...data } : s));
  };

  const deleteSession = (id: string) => {
    setSessions(prev => prev.filter(s => s.id !== id));
  };

  return { sessions, addSession, updateSession, deleteSession };
}

export function useSettings() {
  const [settings, setSettings] = useLocalStorage<Settings>('ev-settings', DEFAULT_SETTINGS);
  return { settings, setSettings };
}

const stationKey = (name: string) => name.trim().toLowerCase();

export function useStationRates() {
  const [stationRates, setStationRates] = useLocalStorage<StationRate[]>('ev-station-rates', []);

  const getStationRate = (name: string) => {
    if (!name?.trim()) return undefined;
    return stationRates.find(s => stationKey(s.name) === stationKey(name));
  };

  const saveStationRate = (name: string, rate: number) => {
    if (!name?.trim() || !rate || isNaN(rate)) return;
    setStationRates(prev => {
      const existing = prev.find(s => stationKey(s.name) === stationKey(name));
      const entry: StationRate = { name: name.trim(), rate, updatedAt: new Date().toISOString() };
      return existing
        ? prev.map(s => (stationKey(s.name) === stationKey(name) ? entry : s))
        : [...prev, entry];
    });
  };

  const deleteStationRate = (name: string) => {
    setStationRates(prev => prev.filter(s => stationKey(s.name) !== stationKey(name)));
  };

  return { stationRates, getStationRate, saveStationRate, deleteStationRate };
}


export function useTrips() {
  const [trips, setTrips] = useLocalStorage<Trip[]>('ev-trips', []);

  const addTrip = (trip: Omit<Trip, 'id' | 'createdAt'>) => {
    const newTrip: Trip = {
      ...trip,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
    setTrips(prev => [...prev, newTrip]);
    return newTrip;
  };

  const updateTrip = (id: string, data: Partial<Trip>) => {
    setTrips(prev => prev.map(t => (t.id === id ? { ...t, ...data } : t)));
  };

  const deleteTrip = (id: string) => {
    setTrips(prev => prev.filter(t => t.id !== id));
  };

  return { trips, addTrip, updateTrip, deleteTrip };
}
