import { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Route, Zap, IndianRupee, Battery } from 'lucide-react';
import { useVehicles, useSettings, useSessions, useStationRates, useTrips } from '@/hooks/useAppData';
import { fleetEfficiency } from '@/lib/tripStats';

const PRESETS = [
  { from: 'Delhi', to: 'Jaipur', km: 280 },
  { from: 'Delhi', to: 'Agra', km: 233 },
  { from: 'Bengaluru', to: 'Chennai', km: 350 },
  { from: 'Mumbai', to: 'Pune', km: 150 },
];

const DEFAULT_STATION = '__default__';

export default function TripCostPlanner() {
  const { vehicles } = useVehicles();
  const { settings } = useSettings();
  const { sessions } = useSessions();
  const { stationRates } = useStationRates();
  const { trips } = useTrips();

  const [from, setFrom] = useState('Delhi');
  const [to, setTo] = useState('Jaipur');
  const [distance, setDistance] = useState('280');
  const [vehicleId, setVehicleId] = useState(vehicles[0]?.id ?? '');
  const [startCharge, setStartCharge] = useState('100');
  const [reserve, setReserve] = useState('15');
  const [roundTrip, setRoundTrip] = useState(false);
  const [stationChoice, setStationChoice] = useState(DEFAULT_STATION);

  const vehicle = vehicles.find(v => v.id === vehicleId) ?? vehicles[0];

  /** Real prices per public station: measured from your logged sessions, or the price you saved. */
  const stationOptions = useMemo(() => {
    const map = new Map<string, { name: string; rate: number; source: 'logged' | 'saved' }>();
    const totals = new Map<string, { name: string; kWh: number; cost: number }>();
    for (const s of sessions) {
      if (s.locationType !== 'public' || !s.kWh) continue;
      const name = (s.location || 'Public station').trim();
      const key = name.toLowerCase();
      const cur = totals.get(key) ?? { name, kWh: 0, cost: 0 };
      cur.kWh += s.kWh;
      cur.cost += s.cost || 0;
      totals.set(key, cur);
    }
    for (const r of stationRates) {
      map.set(r.name.trim().toLowerCase(), { name: r.name.trim(), rate: r.rate, source: 'saved' });
    }
    for (const [key, t] of totals) {
      if (map.has(key) || t.kWh <= 0) continue;
      map.set(key, { name: t.name, rate: t.cost / t.kWh, source: 'logged' });
    }
    return [...map.values()].sort((a, b) => a.rate - b.rate);
  }, [sessions, stationRates]);

  const rates = useMemo(() => {
    const homeSessions = sessions.filter(s => s.locationType === 'home' && s.kWh > 0);
    const homeKWh = homeSessions.reduce((a, s) => a + s.kWh, 0);
    const homeCost = homeSessions.reduce((a, s) => a + (s.cost || 0), 0);
    const home = homeKWh > 0
      ? { rate: homeCost / homeKWh, source: 'your logged home charges' }
      : { rate: settings.electricityRate, source: 'your home rate in Settings' };

    const chosen = stationOptions.find(s => s.name.toLowerCase() === stationChoice.toLowerCase());
    if (chosen) {
      return {
        home,
        public: {
          rate: chosen.rate,
          source: chosen.source === 'saved' ? `saved price at ${chosen.name}` : `what you paid at ${chosen.name}`,
        },
      };
    }
    const cheapest = stationOptions[0];
    return {
      home,
      public: cheapest
        ? {
            rate: cheapest.rate,
            source: `cheapest known station — ${cheapest.name}`,
          }
        : { rate: settings.publicChargingRate, source: 'your public rate in Settings' },
    };
  }, [sessions, settings, stationOptions, stationChoice]);

  /** Real efficiency: trip log first, then logged session distances, then entered range. */
  const efficiencyInfo = useMemo(() => {
    if (!vehicle) return null;
    const tripStats = fleetEfficiency(trips, vehicles, vehicle.id);
    if (tripStats) {
      return {
        kmPerKWh: tripStats.kmPerKWh,
        range: tripStats.kmPerKWh * vehicle.batteryCapacity,
        source: `measured from ${tripStats.tripCount} recorded trip${tripStats.tripCount > 1 ? 's' : ''} (${tripStats.distance.toFixed(0)} ${settings.distanceUnit})`,
        real: true,
      };
    }
    const mine = sessions.filter(s => s.vehicleId === vehicle.id && s.kWh > 0 && (s.tripDistance ?? 0) > 0);
    const km = mine.reduce((a, s) => a + (s.tripDistance ?? 0), 0);
    const kWh = mine.reduce((a, s) => a + s.kWh, 0);
    if (km > 0 && kWh > 0) {
      const kmPerKWh = km / kWh;
      return {
        kmPerKWh,
        range: kmPerKWh * vehicle.batteryCapacity,
        source: `measured from ${mine.length} logged trip${mine.length > 1 ? 's' : ''} (${km.toFixed(0)} ${settings.distanceUnit})`,
        real: true,
      };
    }
    if (vehicle.range && vehicle.range > 0) {
      return {
        kmPerKWh: vehicle.range / vehicle.batteryCapacity,
        range: vehicle.range,
        source: 'range you entered for this vehicle',
        real: false,
      };
    }
    return {
      kmPerKWh: 6,
      range: vehicle.batteryCapacity * 6,
      source: 'general estimate — record trips in the Trip log for real numbers',
      real: false,
    };
  }, [vehicle, vehicles, trips, sessions, settings.distanceUnit]);

  const plan = useMemo(() => {
    const oneWay = parseFloat(distance) || 0;
    const km = roundTrip ? oneWay * 2 : oneWay;
    if (!vehicle || !efficiencyInfo || km <= 0) return null;

    const range = efficiencyInfo.range;
    const efficiency = 1 / efficiencyInfo.kmPerKWh; // kWh per km
    const energy = km * efficiency * (efficiencyInfo.real ? 1.05 : 1.1);

    const startPct = Math.min(100, Math.max(0, parseFloat(startCharge) || 0));
    const reservePct = Math.min(90, Math.max(0, parseFloat(reserve) || 0));
    const usablePct = Math.max(0, startPct - reservePct);
    const fromBattery = Math.min(energy, (usablePct / 100) * vehicle.batteryCapacity);
    const publicEnergy = Math.max(0, energy - fromBattery);

    const perStopPct = Math.max(10, 80 - reservePct);
    const perStopKWh = (perStopPct / 100) * vehicle.batteryCapacity;
    const stops = publicEnergy > 0 ? Math.ceil(publicEnergy / perStopKWh) : 0;

    const homeCost = fromBattery * rates.home.rate;
    const publicCost = publicEnergy * rates.public.rate;

    return {
      km,
      range,
      energy,
      fromBattery,
      publicEnergy,
      stops,
      homeCost,
      publicCost,
      total: homeCost + publicCost,
      perKm: (homeCost + publicCost) / km,
      rangeAtStart: (usablePct / 100) * range,
    };
  }, [distance, roundTrip, vehicle, efficiencyInfo, startCharge, reserve, rates]);

  const c = settings.currencySymbol;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Route className="h-4 w-4" /> Plan a trip
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {PRESETS.map(p => (
              <Button
                key={`${p.from}-${p.to}`}
                type="button"
                variant="outline"
                size="sm"
                onClick={() => { setFrom(p.from); setTo(p.to); setDistance(String(p.km)); }}
              >
                {p.from} → {p.to}
              </Button>
            ))}
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="space-y-1">
              <Label className="text-xs">From</Label>
              <Input value={from} onChange={e => setFrom(e.target.value)} placeholder="Delhi" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">To</Label>
              <Input value={to} onChange={e => setTo(e.target.value)} placeholder="Jaipur" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Distance ({settings.distanceUnit})</Label>
              <Input type="number" value={distance} onChange={e => setDistance(e.target.value)} />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="space-y-1">
              <Label className="text-xs">Vehicle</Label>
              <Select value={vehicle?.id ?? ''} onValueChange={setVehicleId}>
                <SelectTrigger><SelectValue placeholder="Select vehicle" /></SelectTrigger>
                <SelectContent>
                  {vehicles.map(v => <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Start charge %</Label>
              <Input type="number" min="0" max="100" value={startCharge} onChange={e => setStartCharge(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Keep reserve %</Label>
              <Input type="number" min="0" max="90" value={reserve} onChange={e => setReserve(e.target.value)} />
            </div>
          </div>

          <div className="space-y-1">
            <Label className="text-xs">Charging station on the way</Label>
            <Select value={stationChoice} onValueChange={setStationChoice}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value={DEFAULT_STATION}>
                  {stationOptions[0]
                    ? `Cheapest I know — ${stationOptions[0].name} (${c}${stationOptions[0].rate.toFixed(2)}/kWh)`
                    : `Default public rate (${c}${settings.publicChargingRate}/kWh)`}
                </SelectItem>
                {stationOptions.map(s => (
                  <SelectItem key={s.name} value={s.name}>
                    {s.name} — {c}{s.rate.toFixed(2)}/kWh
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button type="button" variant={roundTrip ? 'default' : 'outline'} size="sm" onClick={() => setRoundTrip(r => !r)}>
            {roundTrip ? 'Round trip (there and back)' : 'One way'}
          </Button>
        </CardContent>
      </Card>

      {!vehicle && (
        <Card>
          <CardContent className="p-6 text-center text-sm text-muted-foreground">
            Add a vehicle first so the planner knows your battery size and range.
          </CardContent>
        </Card>
      )}

      {plan && vehicle && efficiencyInfo && (
        <>
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">
                {from || 'Start'} → {to || 'Destination'} · {plan.km.toFixed(0)} {settings.distanceUnit}
              </p>
              <p className="text-3xl font-bold text-primary">{c}{plan.total.toFixed(0)}</p>
              <p className="text-sm text-muted-foreground">
                about {c}{plan.perKm.toFixed(2)} per {settings.distanceUnit} · {plan.energy.toFixed(1)} kWh of energy
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                <Badge variant={efficiencyInfo.real ? 'default' : 'outline'}>
                  {efficiencyInfo.real ? 'Your real mileage' : 'Estimated mileage'}
                </Badge>
                <Badge variant={stationOptions.length ? 'default' : 'outline'}>
                  {stationOptions.length ? 'Real station prices' : 'Default prices'}
                </Badge>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Tile icon={<Battery className="h-4 w-4" />} label="Range at start" value={`${plan.rangeAtStart.toFixed(0)} ${settings.distanceUnit}`} sub={`${efficiencyInfo.kmPerKWh.toFixed(1)} ${settings.distanceUnit}/kWh`} />
            <Tile icon={<Zap className="h-4 w-4" />} label="Charging stops" value={String(plan.stops)} sub={plan.stops === 0 ? 'no stop needed' : 'public top-ups'} />
            <Tile icon={<IndianRupee className="h-4 w-4" />} label="Home energy" value={`${c}${plan.homeCost.toFixed(0)}`} sub={`${plan.fromBattery.toFixed(1)} kWh @ ${c}${rates.home.rate.toFixed(2)}`} />
            <Tile icon={<IndianRupee className="h-4 w-4" />} label="Public energy" value={`${c}${plan.publicCost.toFixed(0)}`} sub={`${plan.publicEnergy.toFixed(1)} kWh @ ${c}${rates.public.rate.toFixed(2)}`} />
          </div>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Where these numbers come from</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-muted-foreground">
              <p>
                Mileage: {efficiencyInfo.kmPerKWh.toFixed(1)} {settings.distanceUnit} per kWh — {efficiencyInfo.source}.
                With a {vehicle.batteryCapacity} kWh battery that is about {efficiencyInfo.range.toFixed(0)}{' '}
                {settings.distanceUnit} on a full charge.
              </p>
              <p>
                Home price: {c}{rates.home.rate.toFixed(2)}/kWh — {rates.home.source}. Public price: {c}
                {rates.public.rate.toFixed(2)}/kWh — {rates.public.source}.
              </p>
              <p>
                Leaving at {startCharge}% you can drive about {plan.rangeAtStart.toFixed(0)} {settings.distanceUnit} before
                dropping to your {reserve}% reserve.{' '}
                {plan.stops === 0
                  ? 'One full charge before you leave is enough for this trip.'
                  : `You will need about ${plan.stops} public stop${plan.stops > 1 ? 's' : ''} on the way.`}
              </p>
              {!efficiencyInfo.real && (
                <p>
                  Log the distance driven with your charging sessions and this planner will switch to your car's real
                  mileage instead of an estimate.
                </p>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

function Tile({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub: string }) {
  return (
    <Card>
      <CardContent className="p-3">
        <div className="flex items-center gap-1.5 text-muted-foreground">
          {icon}
          <span className="text-xs">{label}</span>
        </div>
        <p className="mt-1 text-lg font-bold text-foreground">{value}</p>
        <p className="truncate text-xs text-muted-foreground">{sub}</p>
      </CardContent>
    </Card>
  );
}
