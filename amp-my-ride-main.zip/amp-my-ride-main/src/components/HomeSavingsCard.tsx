import { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useSessions, useSettings } from '@/hooks/useAppData';
import { TrendingDown, Home, Zap } from 'lucide-react';

export function HomeSavingsCard() {
  const { sessions } = useSessions();
  const { settings } = useSettings();

  const data = useMemo(() => {
    const homeSessions = sessions.filter(s => s.locationType === 'home');
    const publicSessions = sessions.filter(s => s.locationType === 'public');

    const homeKwh = homeSessions.reduce((sum, s) => sum + s.kWh, 0);
    const homeCost = homeSessions.reduce((sum, s) => sum + s.cost, 0);
    const publicKwh = publicSessions.reduce((sum, s) => sum + s.kWh, 0);
    const publicCost = publicSessions.reduce((sum, s) => sum + s.cost, 0);

    // What home charging would have cost at public rates
    const homeAtPublicRate = homeKwh * settings.publicChargingRate;
    const savings = homeAtPublicRate - homeCost;

    const homeRate = homeKwh > 0 ? homeCost / homeKwh : settings.electricityRate;
    const publicRate = publicKwh > 0 ? publicCost / publicKwh : settings.publicChargingRate;

    return { homeKwh, homeCost, publicKwh, publicCost, savings, homeRate, publicRate };
  }, [sessions, settings]);

  if (sessions.length === 0) return null;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center gap-2">
          <TrendingDown className="h-4 w-4 text-primary" />
          Home vs Public Savings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-lg bg-primary/10 p-3 text-center">
            <Home className="mx-auto h-4 w-4 text-primary mb-1" />
            <p className="text-xs text-muted-foreground">Home Rate</p>
            <p className="text-lg font-bold text-foreground">
              {settings.currencySymbol}{data.homeRate.toFixed(1)}
            </p>
            <p className="text-xs text-muted-foreground">per kWh</p>
          </div>
          <div className="rounded-lg bg-destructive/10 p-3 text-center">
            <Zap className="mx-auto h-4 w-4 text-destructive mb-1" />
            <p className="text-xs text-muted-foreground">Public Rate</p>
            <p className="text-lg font-bold text-foreground">
              {settings.currencySymbol}{data.publicRate.toFixed(1)}
            </p>
            <p className="text-xs text-muted-foreground">per kWh</p>
          </div>
        </div>

        {data.savings > 0 ? (
          <div className="rounded-lg border border-primary/30 bg-primary/5 p-3 text-center">
            <p className="text-xs text-muted-foreground">You saved by charging at home</p>
            <p className="text-2xl font-bold text-primary">
              {settings.currencySymbol}{data.savings.toFixed(0)}
            </p>
            <p className="text-xs text-muted-foreground">
              ({data.homeKwh.toFixed(1)} kWh at home × {settings.currencySymbol}{(data.publicRate - data.homeRate).toFixed(1)} saved/kWh)
            </p>
          </div>
        ) : (
          <div className="rounded-lg border border-border p-3 text-center">
            <p className="text-xs text-muted-foreground">
              Charge at home to save {settings.currencySymbol}{(settings.publicChargingRate - settings.electricityRate).toFixed(1)}/kWh
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
