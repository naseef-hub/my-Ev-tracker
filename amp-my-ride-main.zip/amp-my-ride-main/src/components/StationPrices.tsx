import { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useSessions, useSettings, useStationRates } from '@/hooks/useAppData';
import { useToast } from '@/hooks/use-toast';
import { Check, Plus, Trash2 } from 'lucide-react';

interface Row {
  name: string;
  saved?: number;
  observed?: number;
  sessions: number;
}

export function StationPrices() {
  const { sessions } = useSessions();
  const { settings } = useSettings();
  const { stationRates, saveStationRate, deleteStationRate } = useStationRates();
  const { toast } = useToast();
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [newName, setNewName] = useState('');
  const [newRate, setNewRate] = useState('');

  const rows = useMemo<Row[]>(() => {
    const map = new Map<string, Row>();
    for (const s of sessions) {
      if (s.locationType !== 'public') continue;
      const name = (s.location || 'Public station').trim();
      const key = name.toLowerCase();
      const cur = map.get(key) ?? { name, sessions: 0 };
      cur.sessions += 1;
      if (s.kWh > 0) cur.observed = s.cost / s.kWh;
      map.set(key, cur);
    }
    for (const r of stationRates) {
      const key = r.name.trim().toLowerCase();
      const cur = map.get(key) ?? { name: r.name, sessions: 0 };
      cur.saved = r.rate;
      map.set(key, cur);
    }
    return [...map.values()].sort((a, b) => a.name.localeCompare(b.name));
  }, [sessions, stationRates]);

  const c = settings.currencySymbol;

  const commit = (name: string, value: string) => {
    const r = parseFloat(value);
    if (!r || isNaN(r) || r <= 0) return;
    saveStationRate(name, r);
    setDrafts(prev => ({ ...prev, [name.toLowerCase()]: '' }));
    toast({ title: 'Price saved', description: `${name} — ${c}${r}/kWh` });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Station Prices</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          Real prices per station. Anything you log for a public charge is remembered automatically; you can correct
          a price here at any time. Stations without a saved price fall back to your default public rate of {c}
          {settings.publicChargingRate}/kWh.
        </p>

        <div className="space-y-2">
          {rows.length === 0 && (
            <p className="text-sm text-muted-foreground">No public stations yet — log a public charge to start.</p>
          )}
          {rows.map(row => {
            const key = row.name.toLowerCase();
            const draft = drafts[key] ?? '';
            return (
              <div key={key} className="rounded-lg border border-border p-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-foreground">{row.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {row.sessions > 0
                        ? `${row.sessions} session${row.sessions > 1 ? 's' : ''}`
                        : 'No sessions yet'}
                      {row.observed ? ` · last paid ${c}${row.observed.toFixed(2)}/kWh` : ''}
                    </p>
                  </div>
                  {row.saved ? (
                    <Badge variant="secondary" className="shrink-0">
                      {c}{row.saved.toFixed(2)}/kWh
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="shrink-0">estimated</Badge>
                  )}
                </div>
                <div className="mt-2 flex gap-2">
                  <Input
                    type="number"
                    step="0.01"
                    inputMode="decimal"
                    placeholder={row.saved ? String(row.saved) : `${settings.publicChargingRate}`}
                    value={draft}
                    onChange={e => setDrafts(prev => ({ ...prev, [key]: e.target.value }))}
                    onKeyDown={e => { if (e.key === 'Enter') commit(row.name, draft); }}
                  />
                  <Button variant="secondary" onClick={() => commit(row.name, draft)} disabled={!draft}>
                    <Check className="h-4 w-4" />
                  </Button>
                  {row.saved ? (
                    <Button
                      variant="ghost"
                      onClick={() => { deleteStationRate(row.name); toast({ title: 'Price removed' }); }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>

        <div className="space-y-2 rounded-lg bg-muted/50 p-3">
          <p className="text-sm font-medium text-foreground">Add a station price</p>
          <div className="flex flex-col gap-2 sm:flex-row">
            <Input placeholder="Station name" value={newName} onChange={e => setNewName(e.target.value)} />
            <Input
              type="number"
              step="0.01"
              inputMode="decimal"
              placeholder={`Price per kWh (${c})`}
              value={newRate}
              onChange={e => setNewRate(e.target.value)}
            />
            <Button
              onClick={() => {
                if (!newName.trim()) return;
                commit(newName.trim(), newRate);
                setNewName('');
                setNewRate('');
              }}
              disabled={!newName.trim() || !newRate}
            >
              <Plus className="h-4 w-4" /> Add
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
