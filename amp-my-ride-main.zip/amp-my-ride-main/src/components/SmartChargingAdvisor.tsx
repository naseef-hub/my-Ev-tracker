import { AdvisorReport } from '@/lib/chargingAdvisor';
import { Settings } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, TrendingDown, PiggyBank, Clock, MapPin, Home, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Props {
  report: AdvisorReport;
  settings: Settings;
  onAskAI: () => void;
  asking?: boolean;
}

export default function SmartChargingAdvisor({ report, settings, onAskAI, asking }: Props) {
  const c = settings.currencySymbol;

  if (!report.hasData) {
    return (
      <Card>
        <CardContent className="p-6 text-center space-y-2">
          <PiggyBank className="mx-auto h-8 w-8 text-muted-foreground" />
          <p className="font-medium text-foreground">No charging history yet</p>
          <p className="text-sm text-muted-foreground">
            Log a few charging sessions and the advisor will show you where and when to charge to save money.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="border-primary/30 bg-primary/5">
        <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Estimated savings available</p>
            <p className="text-2xl font-bold text-primary">
              {c}{report.potentialMonthlySaving.toFixed(0)}
              <span className="ml-1 text-sm font-normal text-muted-foreground">/ month</span>
            </p>
          </div>
          <Button onClick={onAskAI} disabled={asking}>
            <Sparkles className="mr-2 h-4 w-4" />
            Get AI savings plan
          </Button>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="Avg. price" value={`${c}${report.avgRate.toFixed(2)}`} sub="per kWh" icon={<Zap className="h-4 w-4" />} />
        <Stat label="Home rate" value={`${c}${report.homeAvgRate.toFixed(2)}`} sub={`${report.homeKWh.toFixed(0)} kWh`} icon={<Home className="h-4 w-4" />} />
        <Stat label="Public rate" value={`${c}${report.publicAvgRate.toFixed(2)}`} sub={`${report.publicKWh.toFixed(0)} kWh`} icon={<MapPin className="h-4 w-4" />} />
        <Stat label="Total spend" value={`${c}${report.totalCost.toFixed(0)}`} sub={`${report.totalSessions} sessions`} icon={<TrendingDown className="h-4 w-4" />} />
      </div>

      {report.insights.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">What to change</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {report.insights.map((i, idx) => (
              <div key={idx} className="rounded-lg border border-border p-3">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm font-medium text-foreground">{i.title}</p>
                  {i.saving ? (
                    <Badge variant="secondary" className="shrink-0">
                      save {c}{i.saving.toFixed(0)}
                    </Badge>
                  ) : null}
                </div>
                <p className="mt-1 text-sm text-muted-foreground">{i.detail}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <MapPin className="h-4 w-4" /> Where to charge
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {report.stations.map(s => (
            <div key={`${s.type}-${s.name}`} className="flex items-center justify-between gap-2 rounded-lg bg-muted/50 px-3 py-2">
              <div className="min-w-0">
                <p className="truncate text-sm font-medium text-foreground">{s.name}</p>
                <p className="text-xs text-muted-foreground">
                  {s.sessions > 0
                    ? `${s.sessions} session${s.sessions > 1 ? 's' : ''} · ${s.totalKWh.toFixed(1)} kWh · ${c}${s.totalCost.toFixed(0)}`
                    : 'Price saved, not used yet'}
                </p>
              </div>
              <div className="text-right">
                <p className={cn('text-sm font-semibold', s.type === 'home' ? 'text-primary' : 'text-foreground')}>
                  {c}{s.avgRate.toFixed(2)}
                </p>
                <p className="text-xs text-muted-foreground">
                  {s.type === 'home' ? 'Home' : 'Public'} · {s.confirmedRate ? 'real price' : 'estimated'}
                </p>
              </div>
            </div>
          ))}

        </CardContent>
      </Card>

      {report.bestSlots.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <Clock className="h-4 w-4" /> When to charge
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {report.bestSlots.map(slot => (
              <div key={slot.label} className="flex items-center justify-between rounded-lg bg-muted/50 px-3 py-2">
                <div>
                  <p className="text-sm font-medium text-foreground">{slot.label}</p>
                  <p className="text-xs text-muted-foreground">
                    {slot.sessions} session{slot.sessions > 1 ? 's' : ''} · {slot.totalKWh.toFixed(1)} kWh
                  </p>
                </div>
                <p className="text-sm font-semibold">{c}{slot.avgRate.toFixed(2)}<span className="text-xs font-normal text-muted-foreground">/kWh</span></p>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function Stat({ label, value, sub, icon }: { label: string; value: string; sub: string; icon: React.ReactNode }) {
  return (
    <Card>
      <CardContent className="p-3">
        <div className="flex items-center gap-1.5 text-muted-foreground">
          {icon}
          <span className="text-xs">{label}</span>
        </div>
        <p className="mt-1 text-lg font-bold text-foreground">{value}</p>
        <p className="text-xs text-muted-foreground">{sub}</p>
      </CardContent>
    </Card>
  );
}
