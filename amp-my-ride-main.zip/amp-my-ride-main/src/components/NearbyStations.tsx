import { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { MapPin, Search, Navigation, Loader2, Route, ExternalLink, Zap, Clock, BatteryCharging, Flag } from 'lucide-react';
import { useVehicles, useSettings } from '@/hooks/useAppData';

interface PlanStop {
  index: number;
  atKm: number;
  arriveAtPct: number;
  chargeToPct: number;
  kwhAdded: number;
  chargeTimeMin: number;
}

interface ChargingPlan {
  feasible: boolean;
  reason?: string;
  stops: PlanStop[];
  finalArrivalPct: number;
  totalDriveMin: number;
  totalChargeMin: number;
}

export function NearbyStations() {
  const { vehicles } = useVehicles();
  const { settings } = useSettings();
  const unit = settings.distanceUnit;

  const [locating, setLocating] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [mapQuery, setMapQuery] = useState('EV charging stations near me');

  // Trip planner state
  const [startPoint, setStartPoint] = useState('');
  const [endPoint, setEndPoint] = useState('');
  const [tripPlanned, setTripPlanned] = useState<{ start: string; end: string } | null>(null);
  const [locatingStart, setLocatingStart] = useState(false);

  // Charging plan inputs
  const [vehicleId, setVehicleId] = useState<string>(vehicles[0]?.id ?? '');
  const [tripDistance, setTripDistance] = useState<string>('');
  const [startPct, setStartPct] = useState<string>('90');
  const [reservePct, setReservePct] = useState<string>('10');
  const [chargeToPct, setChargeToPct] = useState<string>('80');
  const [targetArrivalPct, setTargetArrivalPct] = useState<string>('15');
  const [chargerKw, setChargerKw] = useState<string>('50');
  const [avgSpeed, setAvgSpeed] = useState<string>(unit === 'km' ? '70' : '45');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setMapQuery(`EV charging stations near ${searchQuery.trim()}`);
    }
  };

  const useMyLocation = () => {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setMapQuery(`EV charging stations near ${pos.coords.latitude},${pos.coords.longitude}`);
        setLocating(false);
      },
      () => setLocating(false),
      { enableHighAccuracy: true, timeout: 5000 }
    );
  };

  const useMyLocationAsStart = () => {
    if (!navigator.geolocation) return;
    setLocatingStart(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setStartPoint(`${pos.coords.latitude},${pos.coords.longitude}`);
        setLocatingStart(false);
      },
      () => setLocatingStart(false),
      { enableHighAccuracy: true, timeout: 5000 }
    );
  };

  const handlePlanTrip = (e: React.FormEvent) => {
    e.preventDefault();
    if (startPoint.trim() && endPoint.trim()) {
      setTripPlanned({ start: startPoint.trim(), end: endPoint.trim() });
    }
  };

  const selectedVehicle = vehicles.find(v => v.id === vehicleId);

  const chargingPlan: ChargingPlan | null = useMemo(() => {
    const dist = parseFloat(tripDistance);
    const start = parseFloat(startPct);
    const reserve = parseFloat(reservePct);
    const chargeTo = parseFloat(chargeToPct);
    const arrive = parseFloat(targetArrivalPct);
    const kw = parseFloat(chargerKw);
    const speed = parseFloat(avgSpeed);

    if (!selectedVehicle || !selectedVehicle.range || !selectedVehicle.batteryCapacity) return null;
    if (!(dist > 0) || !(kw > 0) || !(speed > 0)) return null;
    if (isNaN(start) || isNaN(reserve) || isNaN(chargeTo) || isNaN(arrive)) return null;
    if (chargeTo <= reserve) {
      return { feasible: false, reason: 'Charge-to % must be greater than reserve %.', stops: [], finalArrivalPct: 0, totalDriveMin: 0, totalChargeMin: 0 };
    }
    if (start <= reserve) {
      return { feasible: false, reason: 'Starting charge must be above reserve %.', stops: [], finalArrivalPct: 0, totalDriveMin: 0, totalChargeMin: 0 };
    }

    const range = selectedVehicle.range;
    const battery = selectedVehicle.batteryCapacity;
    const kmPerPct = range / 100;

    let distanceLeft = dist;
    let currentPct = start;
    let distanceDriven = 0;
    const stops: PlanStop[] = [];
    let safety = 0;

    while (safety++ < 20) {
      const arrivalIfNoStop = currentPct - distanceLeft / kmPerPct;
      if (arrivalIfNoStop >= arrive) {
        return {
          feasible: true,
          stops,
          finalArrivalPct: arrivalIfNoStop,
          totalDriveMin: (dist / speed) * 60,
          totalChargeMin: stops.reduce((s, x) => s + x.chargeTimeMin, 0),
        };
      }
      // Need a stop. Drive until reserve.
      const legKm = (currentPct - reserve) * kmPerPct;
      if (legKm <= 0) {
        return { feasible: false, reason: 'Not enough range to reach a stop before reserve.', stops, finalArrivalPct: 0, totalDriveMin: 0, totalChargeMin: 0 };
      }
      distanceDriven += legKm;
      distanceLeft -= legKm;
      const kwhAdded = battery * (chargeTo - reserve) / 100;
      const chargeTimeMin = (kwhAdded / kw) * 60;
      stops.push({
        index: stops.length + 1,
        atKm: distanceDriven,
        arriveAtPct: reserve,
        chargeToPct: chargeTo,
        kwhAdded,
        chargeTimeMin,
      });
      currentPct = chargeTo;
    }
    return { feasible: false, reason: 'Too many stops required — increase charge-to % or reduce target arrival.', stops, finalArrivalPct: 0, totalDriveMin: 0, totalChargeMin: 0 };
  }, [selectedVehicle, tripDistance, startPct, reservePct, chargeToPct, targetArrivalPct, chargerKw, avgSpeed]);

  const formatMin = (m: number) => {
    const h = Math.floor(m / 60);
    const min = Math.round(m % 60);
    return h > 0 ? `${h}h ${min}m` : `${min}m`;
  };

  const mapSrc = `https://www.google.com/maps?q=${encodeURIComponent(mapQuery)}&output=embed`;

  const routeSrc = tripPlanned
    ? `https://www.google.com/maps?saddr=${encodeURIComponent(tripPlanned.start)}&daddr=${encodeURIComponent(tripPlanned.end)}&output=embed`
    : '';

  const stationsAlongSrc = tripPlanned
    ? `https://www.google.com/maps?q=${encodeURIComponent(`EV charging stations between ${tripPlanned.start} and ${tripPlanned.end}`)}&output=embed`
    : '';

  const fullMapsLink = tripPlanned
    ? `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(tripPlanned.start)}&destination=${encodeURIComponent(tripPlanned.end)}&travelmode=driving`
    : '';

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center gap-2">
          <MapPin className="h-4 w-4 text-primary" />
          Nearby Charging Stations
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="nearby" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-3">
            <TabsTrigger value="nearby" className="gap-1.5">
              <MapPin className="h-3.5 w-3.5" /> Nearby
            </TabsTrigger>
            <TabsTrigger value="trip" className="gap-1.5">
              <Route className="h-3.5 w-3.5" /> Trip Planner
            </TabsTrigger>
          </TabsList>

          <TabsContent value="nearby" className="space-y-3 mt-0">
            <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-2">
              <Input
                placeholder="Search city or area (e.g. Mumbai, Delhi)"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="text-sm min-w-0"
              />
              <div className="flex gap-2">
                <Button type="submit" size="sm" className="gap-1.5 flex-1 sm:flex-none" disabled={!searchQuery.trim()}>
                  <Search className="h-3.5 w-3.5" /> Search
                </Button>
                <Button type="button" variant="outline" size="sm" className="gap-1.5 flex-1 sm:flex-none" onClick={useMyLocation} disabled={locating}>
                  {locating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Navigation className="h-3.5 w-3.5" />}
                  My Location
                </Button>
              </div>
            </form>
            <div className="h-72 rounded-lg overflow-hidden border border-border">
              <iframe
                title="Google Maps - EV Charging Stations"
                src={mapSrc}
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </TabsContent>

          <TabsContent value="trip" className="space-y-3 mt-0">
            <form onSubmit={handlePlanTrip} className="space-y-2">
              <div className="space-y-1.5">
                <Label className="text-xs">Start point</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="e.g. Mumbai, or Home address"
                    value={startPoint}
                    onChange={e => setStartPoint(e.target.value)}
                    className="text-sm min-w-0"
                  />
                  <Button type="button" variant="outline" size="sm" className="shrink-0 gap-1.5" onClick={useMyLocationAsStart} disabled={locatingStart}>
                    {locatingStart ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Navigation className="h-3.5 w-3.5" />}
                  </Button>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Destination</Label>
                <Input
                  placeholder="e.g. Pune, or destination address"
                  value={endPoint}
                  onChange={e => setEndPoint(e.target.value)}
                  className="text-sm min-w-0"
                />
              </div>
              <Button type="submit" size="sm" className="w-full gap-1.5" disabled={!startPoint.trim() || !endPoint.trim()}>
                <Route className="h-3.5 w-3.5" /> Plan Trip
              </Button>
            </form>

            {tripPlanned && (
              <div className="space-y-3">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <Label className="text-xs font-medium">Route</Label>
                    <a
                      href={fullMapsLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-primary hover:underline flex items-center gap-1"
                    >
                      Open in Google Maps <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                  <div className="h-64 rounded-lg overflow-hidden border border-border">
                    <iframe
                      title="Trip Route"
                      src={routeSrc}
                      width="100%"
                      height="100%"
                      style={{ border: 0 }}
                      allowFullScreen
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                    />
                  </div>
                </div>
                <div>
                  <Label className="text-xs font-medium mb-1.5 block">Charging stations along the way</Label>
                  <div className="h-64 rounded-lg overflow-hidden border border-border">
                    <iframe
                      title="Charging Stations Along Route"
                      src={stationsAlongSrc}
                      width="100%"
                      height="100%"
                      style={{ border: 0 }}
                      allowFullScreen
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Charging Plan */}
            <div className="border-t border-border pt-3 space-y-3">
              <div className="flex items-center gap-2">
                <BatteryCharging className="h-4 w-4 text-primary" />
                <h3 className="text-sm font-medium">Charging Plan</h3>
              </div>

              {vehicles.length === 0 ? (
                <p className="text-xs text-muted-foreground">Add a vehicle (with battery capacity and rated range) to generate a charging plan.</p>
              ) : (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div className="space-y-1 sm:col-span-2">
                      <Label className="text-xs">Vehicle</Label>
                      <Select value={vehicleId} onValueChange={setVehicleId}>
                        <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="Select vehicle" /></SelectTrigger>
                        <SelectContent>
                          {vehicles.map(v => (
                            <SelectItem key={v.id} value={v.id}>
                              {v.name} {v.range ? `· ${v.range} ${unit}` : ''} {v.batteryCapacity ? `· ${v.batteryCapacity} kWh` : ''}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Trip distance ({unit})</Label>
                      <Input type="number" inputMode="decimal" value={tripDistance} onChange={e => setTripDistance(e.target.value)} placeholder="e.g. 250" className="h-9 text-sm" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Avg driving speed ({unit}/h)</Label>
                      <Input type="number" inputMode="decimal" value={avgSpeed} onChange={e => setAvgSpeed(e.target.value)} className="h-9 text-sm" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Start charge (%)</Label>
                      <Input type="number" inputMode="decimal" value={startPct} onChange={e => setStartPct(e.target.value)} className="h-9 text-sm" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Target arrival (%)</Label>
                      <Input type="number" inputMode="decimal" value={targetArrivalPct} onChange={e => setTargetArrivalPct(e.target.value)} className="h-9 text-sm" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Reserve at stops (%)</Label>
                      <Input type="number" inputMode="decimal" value={reservePct} onChange={e => setReservePct(e.target.value)} className="h-9 text-sm" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Charge up to (%)</Label>
                      <Input type="number" inputMode="decimal" value={chargeToPct} onChange={e => setChargeToPct(e.target.value)} className="h-9 text-sm" />
                    </div>
                    <div className="space-y-1 sm:col-span-2">
                      <Label className="text-xs">Charger speed (kW)</Label>
                      <Input type="number" inputMode="decimal" value={chargerKw} onChange={e => setChargerKw(e.target.value)} className="h-9 text-sm" />
                    </div>
                  </div>

                  {!chargingPlan && (
                    <p className="text-xs text-muted-foreground">Enter trip distance and ensure your vehicle has battery capacity and rated range configured.</p>
                  )}

                  {chargingPlan && !chargingPlan.feasible && (
                    <div className="rounded-md border border-destructive/40 bg-destructive/5 p-2.5 text-xs text-destructive">
                      {chargingPlan.reason}
                    </div>
                  )}

                  {chargingPlan && chargingPlan.feasible && (
                    <div className="space-y-3">
                      <div className="grid grid-cols-3 gap-2">
                        <div className="rounded-md border border-border p-2 text-center">
                          <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Stops</div>
                          <div className="text-base font-semibold">{chargingPlan.stops.length}</div>
                        </div>
                        <div className="rounded-md border border-border p-2 text-center">
                          <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Drive time</div>
                          <div className="text-base font-semibold">{formatMin(chargingPlan.totalDriveMin)}</div>
                        </div>
                        <div className="rounded-md border border-border p-2 text-center">
                          <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Charge time</div>
                          <div className="text-base font-semibold">{formatMin(chargingPlan.totalChargeMin)}</div>
                        </div>
                      </div>

                      <div className="text-xs text-muted-foreground">
                        Total trip: <span className="font-medium text-foreground">{formatMin(chargingPlan.totalDriveMin + chargingPlan.totalChargeMin)}</span>
                        {chargingPlan.totalChargeMin > 0 && (
                          <> · Charging adds <span className="font-medium text-foreground">{formatMin(chargingPlan.totalChargeMin)}</span></>
                        )}
                      </div>

                      {chargingPlan.stops.length === 0 ? (
                        <div className="rounded-md border border-border bg-muted/30 p-2.5 text-xs">
                          No charging stops needed. You'll arrive with <span className="font-semibold text-primary">{chargingPlan.finalArrivalPct.toFixed(0)}%</span> remaining.
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {chargingPlan.stops.map(stop => (
                            <div key={stop.index} className="rounded-md border border-border p-2.5 space-y-1.5">
                              <div className="flex items-center justify-between gap-2">
                                <div className="flex items-center gap-1.5 text-sm font-medium">
                                  <Zap className="h-3.5 w-3.5 text-primary" />
                                  Stop {stop.index}
                                </div>
                                <Badge variant="secondary" className="text-[10px]">at {stop.atKm.toFixed(0)} {unit}</Badge>
                              </div>
                              <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
                                <span>Arrive: <span className="font-medium text-foreground">{stop.arriveAtPct.toFixed(0)}%</span></span>
                                <span>Charge to: <span className="font-medium text-foreground">{stop.chargeToPct.toFixed(0)}%</span></span>
                                <span>+{stop.kwhAdded.toFixed(1)} kWh</span>
                                <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {formatMin(stop.chargeTimeMin)}</span>
                              </div>
                            </div>
                          ))}
                          <div className="rounded-md border border-primary/40 bg-primary/5 p-2.5 flex items-center gap-2 text-xs">
                            <Flag className="h-3.5 w-3.5 text-primary" />
                            Arrive at destination with <span className="font-semibold text-primary">{chargingPlan.finalArrivalPct.toFixed(0)}%</span> remaining
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
