import { useState } from 'react';
import { Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useVehicles, useSessions, useSettings, useStationRates } from '@/hooks/useAppData';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';

export function QuickAddSession() {
  const { vehicles } = useVehicles();
  const { addSession } = useSessions();
  const { settings } = useSettings();
  const { stationRates, getStationRate, saveStationRate } = useStationRates();
  const [rememberRate, setRememberRate] = useState(true);
  const { toast } = useToast();
  const [open, setOpen] = useState(false);

  const [form, setForm] = useState({
    vehicleId: '',
    kWh: '',
    cost: '',
    rate: String(settings.electricityRate),
    locationType: 'home' as 'home' | 'public',
    location: '',
  });

  const resetForm = () => setForm({ vehicleId: '', kWh: '', cost: '', rate: String(settings.electricityRate), locationType: 'home', location: '' });


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.vehicleId || !form.kWh || !form.cost) {
      toast({ title: 'Missing fields', description: 'Please fill in vehicle, kWh, and cost.', variant: 'destructive' });
      return;
    }
    addSession({
      vehicleId: form.vehicleId,
      date: new Date().toISOString(),
      kWh: parseFloat(form.kWh),
      cost: parseFloat(form.cost),
      location: form.location || (form.locationType === 'home' ? 'Home' : 'Public Station'),
      locationType: form.locationType,
      odometerReading: 0,
    });
    if (form.locationType === 'public' && rememberRate && form.location.trim()) {
      const r = parseFloat(form.rate);
      if (r > 0) saveStationRate(form.location, r);
    }
    toast({ title: 'Session added!' });
    resetForm();
    setOpen(false);
  };

  if (vehicles.length === 0) return null;

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) resetForm(); }}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline" className="gap-1.5">
          <Zap className="h-4 w-4" /> Quick Add
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Quick Add Session</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-2">
          <div className="space-y-2">
            <Label>Vehicle</Label>
            <Select value={form.vehicleId} onValueChange={v => setForm(p => ({ ...p, vehicleId: v }))}>
              <SelectTrigger><SelectValue placeholder="Select vehicle" /></SelectTrigger>
              <SelectContent>
                {vehicles.map(v => (
                  <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Location Type</Label>
            <Select value={form.locationType} onValueChange={v => {
              const locationType = v as 'home' | 'public';
              const saved = locationType === 'public' ? getStationRate(form.location)?.rate : undefined;
              const rate = saved ?? (locationType === 'public' ? settings.publicChargingRate : settings.electricityRate);
              const cost = form.kWh && rate ? (parseFloat(form.kWh) * rate).toFixed(2) : form.cost;
              setForm(p => ({ ...p, locationType, rate: String(rate), cost }));
            }}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="home">Home</SelectItem>
                <SelectItem value="public">Public Station</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>
              {form.locationType === 'public' ? 'Station rate' : 'Home rate'} ({settings.currencySymbol}/kWh)
            </Label>
            <Input
              type="number"
              step="0.01"
              inputMode="decimal"
              placeholder="e.g. 18"
              value={form.rate}
              onChange={e => {
                const rate = e.target.value;
                const r = parseFloat(rate);
                const cost = form.kWh && !isNaN(r) ? (parseFloat(form.kWh) * r).toFixed(2) : form.cost;
                setForm(p => ({ ...p, rate, cost }));
              }}
            />
            {form.locationType === 'public' && (
              <>
                <div className="flex items-center gap-2 pt-1">
                  <Checkbox
                    id="quick-remember-rate"
                    checked={rememberRate}
                    onCheckedChange={v => setRememberRate(v === true)}
                  />
                  <Label htmlFor="quick-remember-rate" className="text-xs font-normal text-muted-foreground">
                    Remember this rate for this station
                  </Label>
                </div>
                <p className="text-xs text-muted-foreground">Edit for this station — it auto-fills next time.</p>
              </>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>kWh</Label>
              <Input
                type="number"
                step="0.1"
                placeholder="e.g. 25"
                value={form.kWh}
                onChange={e => {
                  const kWh = e.target.value;
                  const rate = parseFloat(form.rate);
                  const cost = kWh && !isNaN(rate) ? (parseFloat(kWh) * rate).toFixed(2) : '';
                  setForm(p => ({ ...p, kWh, cost: cost || p.cost }));
                }}
              />
            </div>

            <div className="space-y-2">
              <Label>Cost ({settings.currencySymbol})</Label>
              <Input
                type="number"
                step="0.01"
                placeholder="e.g. 200"
                value={form.cost}
                onChange={e => setForm(p => ({ ...p, cost: e.target.value }))}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Location Name (optional)</Label>
            <Input
              list="quick-saved-stations"
              placeholder={form.locationType === 'home' ? 'Home' : 'Station name'}
              value={form.location}
              onChange={e => {
                const location = e.target.value;
                const saved = form.locationType === 'public' ? getStationRate(location)?.rate : undefined;
                if (saved) {
                  const cost = form.kWh ? (parseFloat(form.kWh) * saved).toFixed(2) : form.cost;
                  setForm(p => ({ ...p, location, rate: String(saved), cost }));
                } else {
                  setForm(p => ({ ...p, location }));
                }
              }}
            />
            <datalist id="quick-saved-stations">
              {stationRates.map(s => (
                <option key={s.name} value={s.name} />
              ))}
            </datalist>
          </div>

          <Button type="submit" className="w-full">Add Session</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
