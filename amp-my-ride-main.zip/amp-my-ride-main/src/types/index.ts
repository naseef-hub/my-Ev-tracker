export interface Vehicle {
  id: string;
  name: string;
  make: string;
  model: string;
  batteryCapacity: number; // kWh
  range?: number; // estimated range per full charge (km or miles based on settings)
  createdAt: string;
}

export interface ChargingSession {
  id: string;
  vehicleId: string;
  date: string; // ISO string
  kWh: number;
  cost: number;
  location: string;
  locationType: 'home' | 'public';
  odometerReading: number;
  tripDistance?: number; // km/miles driven since previous charge (auto or override)
  batteryStart?: number; // battery % when charging started
  batteryEnd?: number; // battery % when charging finished
  notes?: string;
  createdAt: string;
}

export interface StationRate {
  name: string;
  rate: number; // currency per kWh
  updatedAt: string;
}

export interface Settings {
  currency: string;
  currencySymbol: string;
  distanceUnit: 'km' | 'miles';
  electricityRate: number; // cost per kWh for home charging
  publicChargingRate: number; // cost per kWh for public charging
}

export const DEFAULT_SETTINGS: Settings = {
  currency: 'INR',
  currencySymbol: '₹',
  distanceUnit: 'km',
  electricityRate: 7,
  publicChargingRate: 15,
};

export interface Trip {
  id: string;
  vehicleId: string;
  date: string; // ISO string
  label?: string; // e.g. "Delhi to Jaipur"
  odometerStart: number;
  odometerEnd: number;
  energyUsed?: number; // kWh used for the trip (manual)
  batteryStart?: number; // battery % at trip start
  batteryEnd?: number; // battery % at trip end
  notes?: string;
  createdAt: string;
}
