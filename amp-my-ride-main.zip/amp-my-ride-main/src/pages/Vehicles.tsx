import { useState } from 'react';
import { Car, Plus, Pencil, Trash2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useVehicles, useSessions, useSettings } from '@/hooks/useAppData';
import { useToast } from '@/hooks/use-toast';
import { Vehicle } from '@/types';

const Vehicles = () => {
  const { vehicles, addVehicle, updateVehicle, deleteVehicle } = useVehicles();
  const { sessions } = useSessions();
  const { settings } = useSettings();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [editVehicle, setEditVehicle] = useState<Vehicle | null>(null);
  const [form, setForm] = useState({ name: '', make: '', model: '', batteryCapacity: '', range: '' });

  const openAdd = () => {
    setEditVehicle(null);
    setForm({ name: '', make: '', model: '', batteryCapacity: '', range: '' });
    setOpen(true);
  };

  const openEdit = (v: Vehicle) => {
    setEditVehicle(v);
    setForm({ name: v.name, make: v.make, model: v.model, batteryCapacity: v.batteryCapacity.toString(), range: v.range?.toString() || '' });
    setOpen(true);
  };

  const handleSubmit = () => {
    if (!form.name || !form.make) {
      toast({ title: 'Name and make are required', variant: 'destructive' });
      return;
    }
    const payload = {
      name: form.name,
      make: form.make,
      model: form.model,
      batteryCapacity: parseFloat(form.batteryCapacity) || 0,
      range: parseFloat(form.range) || 0,
    };
    if (editVehicle) {
      updateVehicle(editVehicle.id, payload);
      toast({ title: 'Vehicle updated' });
    } else {
      addVehicle(payload);
      toast({ title: 'Vehicle added!' });
    }
    setOpen(false);
  };

  const handleDelete = (id: string) => {
    deleteVehicle(id);
    toast({ title: 'Vehicle deleted' });
  };

  const getVehicleStats = (vehicleId: string) => {
    const vehicleSessions = sessions.filter(s => s.vehicleId === vehicleId);
    const totalCost = vehicleSessions.reduce((sum, s) => sum + s.cost, 0);
    const totalKwh = vehicleSessions.reduce((sum, s) => sum + s.kWh, 0);
    return { totalCost, totalKwh, count: vehicleSessions.length };
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-foreground">Vehicles</h1>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button onClick={openAdd}><Plus className="h-4 w-4" /> Add Vehicle</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editVehicle ? 'Edit' : 'Add'} Vehicle</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label>Vehicle Name</Label>
                <Input placeholder="e.g. My Tesla" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Make</Label>
                  <Input placeholder="e.g. Tesla" value={form.make} onChange={e => setForm(p => ({ ...p, make: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>Model</Label>
                  <Input placeholder="e.g. Model 3" value={form.model} onChange={e => setForm(p => ({ ...p, model: e.target.value }))} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Battery Capacity (kWh)</Label>
                  <Input type="number" placeholder="e.g. 75" value={form.batteryCapacity} onChange={e => setForm(p => ({ ...p, batteryCapacity: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>Range ({settings.distanceUnit})</Label>
                  <Input type="number" placeholder="e.g. 400" value={form.range} onChange={e => setForm(p => ({ ...p, range: e.target.value }))} />
                </div>
              </div>
              <Button onClick={handleSubmit} className="w-full">{editVehicle ? 'Update' : 'Add'} Vehicle</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {vehicles.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-8">
            <Car className="h-12 w-12 text-muted-foreground" />
            <p className="text-muted-foreground">No vehicles added yet</p>
            <Button onClick={openAdd}>Add Your First Vehicle</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {vehicles.map(v => {
            const stats = getVehicleStats(v.id);
            return (
              <Card key={v.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                        <Car className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-base">{v.name}</CardTitle>
                        <p className="text-sm text-muted-foreground">{v.make} {v.model}</p>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" onClick={() => openEdit(v)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDelete(v.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="rounded-lg bg-muted p-2">
                      <p className="text-lg font-bold text-foreground">{stats.count}</p>
                      <p className="text-xs text-muted-foreground">Sessions</p>
                    </div>
                    <div className="rounded-lg bg-muted p-2">
                      <p className="text-lg font-bold text-foreground">{stats.totalKwh.toFixed(0)}</p>
                      <p className="text-xs text-muted-foreground">kWh</p>
                    </div>
                    <div className="rounded-lg bg-muted p-2">
                      <p className="text-lg font-bold text-foreground">{settings.currencySymbol}{stats.totalCost.toFixed(0)}</p>
                      <p className="text-xs text-muted-foreground">Spent</p>
                    </div>
                  </div>
                  {(v.batteryCapacity > 0 || (v.range && v.range > 0)) && (
                    <p className="mt-2 text-xs text-muted-foreground">
                      {v.batteryCapacity > 0 && <>Battery: {v.batteryCapacity} kWh</>}
                      {v.batteryCapacity > 0 && v.range && v.range > 0 && ' • '}
                      {v.range && v.range > 0 && <>Range: {v.range} {settings.distanceUnit}</>}
                    </p>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default Vehicles;
