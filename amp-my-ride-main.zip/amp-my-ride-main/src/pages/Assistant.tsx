import { useMemo, useRef, useState } from 'react';
import { Sparkles, Send, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import TripCostPlanner from '@/components/TripCostPlanner';
import { useVehicles, useSessions, useSettings, useStationRates } from '@/hooks/useAppData';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

const SUGGESTIONS = [
  'How much did I spend on charging this month?',
  'Am I saving money charging at home?',
  'What is my real range per full charge?',
  'Which charging station is cheapest for me?',
];

export default function Assistant() {
  const { vehicles } = useVehicles();
  const { sessions } = useSessions();
  const { settings } = useSettings();
  const { stationRates } = useStationRates();

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const snapshot = useMemo(() => {
    const sorted = [...sessions].sort((a, b) => (a.date < b.date ? 1 : -1));
    return {
      settings,
      vehicles,
      stationRates,
      totalSessions: sessions.length,
      totalCost: sessions.reduce((s, x) => s + (x.cost || 0), 0),
      totalKWh: sessions.reduce((s, x) => s + (x.kWh || 0), 0),
      recentSessions: sorted.slice(0, 60),
    };
  }, [sessions, vehicles, settings, stationRates]);

  const send = async (text: string) => {
    const question = text.trim();
    if (!question || loading) return;

    const next: ChatMessage[] = [...messages, { role: 'user', content: question }];
    setMessages(next);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ev-assistant`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        },
        body: JSON.stringify({ messages: next, snapshot }),
      });

      if (!res.ok || !res.body) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || 'The assistant is unavailable right now.');
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let assistantText = '';
      setMessages([...next, { role: 'assistant', content: '' }]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const payload = line.slice(6).trim();
          if (payload === '[DONE]') continue;
          try {
            const json = JSON.parse(payload);
            const delta = json.choices?.[0]?.delta?.content;
            if (delta) {
              assistantText += delta;
              setMessages([...next, { role: 'assistant', content: assistantText }]);
              scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
            }
          } catch {
            /* partial chunk */
          }
        }
      }
    } catch (e) {
      setMessages(next);
      toast({
        title: 'Assistant error',
        description: e instanceof Error ? e.message : 'Something went wrong.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
          <Sparkles className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">AI Assistant</h1>
          <p className="text-sm text-muted-foreground">Ask about your charging costs, savings and mileage</p>
        </div>
      </div>

      <Tabs defaultValue="chat" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="chat">Ask AI</TabsTrigger>
          <TabsTrigger value="trip">Trip planner</TabsTrigger>
        </TabsList>

        <TabsContent value="trip" className="space-y-4">
          <TripCostPlanner />
        </TabsContent>

        <TabsContent value="chat">
      <Card>
        <CardContent className="p-4">
          <div ref={scrollRef} className="max-h-[52vh] min-h-[220px] space-y-3 overflow-y-auto pr-1">
            {messages.length === 0 && (
              <div className="space-y-3 py-4">
                <p className="text-sm text-muted-foreground">Try one of these:</p>
                <div className="flex flex-wrap gap-2">
                  {SUGGESTIONS.map(s => (
                    <Button key={s} variant="outline" size="sm" onClick={() => send(s)}>
                      {s}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((m, i) => (
              <div key={i} className={cn('flex', m.role === 'user' ? 'justify-end' : 'justify-start')}>
                <div
                  className={cn(
                    'max-w-[85%] whitespace-pre-wrap rounded-lg px-3 py-2 text-sm',
                    m.role === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-foreground'
                  )}
                >
                  {m.content || '…'}
                </div>
              </div>
            ))}

            {loading && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" /> Thinking…
              </div>
            )}
          </div>

          <form
            className="mt-4 flex gap-2"
            onSubmit={e => {
              e.preventDefault();
              send(input);
            }}
          >
            <Input
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder="Ask about your charging data…"
            />
            <Button type="submit" size="icon" disabled={loading || !input.trim()}>
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </CardContent>
      </Card>
        </TabsContent>
      </Tabs>

      <p className="text-xs text-muted-foreground">
        Your data stays on this device — only a summary is sent so the assistant can answer with your real numbers.
      </p>
    </div>
  );
}
