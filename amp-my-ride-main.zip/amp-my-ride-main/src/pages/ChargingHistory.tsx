import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Download, Search, Pencil, Trash2, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useVehicles, useSessions, useSettings } from '@/hooks/useAppData';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

const ChargingHistory = () => {
  const { vehicles } = useVehicles();
  const { sessions, deleteSession } = useSessions();
  const { settings } = useSettings();
  const { toast } = useToast();

  const [search, setSearch] = useState('');
  const [vehicleFilter, setVehicleFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState<'all' | 'home' | 'public'>('all');
  const [sortBy, setSortBy] = useState<'date' | 'cost' | 'kWh'>('date');

  const filtered = useMemo(() => {
    let result = [...sessions];
    if (vehicleFilter !== 'all') result = result.filter(s => s.vehicleId === vehicleFilter);
    if (typeFilter !== 'all') result = result.filter(s => (s.locationType || 'home') === typeFilter);
    if (search) result = result.filter(s => s.location.toLowerCase().includes(search.toLowerCase()));
    result.sort((a, b) => {
      if (sortBy === 'date') return new Date(b.date).getTime() - new Date(a.date).getTime();
      if (sortBy === 'cost') return b.cost - a.cost;
      return b.kWh - a.kWh;
    });
    return result;
  }, [sessions, vehicleFilter, typeFilter, search, sortBy]);


  const totals = useMemo(() => {
    const kWh = filtered.reduce((a, s) => a + (s.kWh || 0), 0);
    const cost = filtered.reduce((a, s) => a + (s.cost || 0), 0);
    return { kWh, cost, count: filtered.length };
  }, [filtered]);

  const rangeSummary = useMemo(() => {
    const ranges: number[] = [];
    for (const s of filtered) {
      const v = vehicles.find(v => v.id === s.vehicleId);
      if (v && v.range && v.batteryCapacity) {
        ranges.push((s.kWh / v.batteryCapacity) * v.range);
      }
    }
    if (ranges.length === 0) return null;
    const total = ranges.reduce((a, b) => a + b, 0);
    return {
      count: ranges.length,
      total,
      avg: total / ranges.length,
      min: Math.min(...ranges),
      max: Math.max(...ranges),
    };
  }, [filtered, vehicles]);

  const exportCSV = () => {
    const headers = ['Date', 'Vehicle', 'kWh', 'Cost', 'Location', 'Type', 'Odometer', `Est. Range (${settings.distanceUnit})`];
    const rows = filtered.map(s => {
      const v = vehicles.find(v => v.id === s.vehicleId);
      const estRange = v && v.range && v.batteryCapacity
        ? ((s.kWh / v.batteryCapacity) * v.range).toFixed(1)
        : '';
      return [
        format(new Date(s.date), 'yyyy-MM-dd HH:mm'),
        v?.name || '',
        s.kWh,
        s.cost,
        s.location,
        s.locationType,
        s.odometerReading,
        estRange,
      ].join(',');
    });
    const csv = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ev-sessions-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: 'CSV exported!' });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-foreground">Charging History</h1>
        <Button variant="outline" size="sm" onClick={exportCSV} disabled={filtered.length === 0}>
          <Download className="h-4 w-4" /> Export
        </Button>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search location..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={vehicleFilter} onValueChange={setVehicleFilter}>
          <SelectTrigger className="w-full sm:w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Vehicles</SelectItem>
            {vehicles.map(v => <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={typeFilter} onValueChange={v => setTypeFilter(v as typeof typeFilter)}>
          <SelectTrigger className="w-full sm:w-36"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="home">Home</SelectItem>
            <SelectItem value="public">Public</SelectItem>
          </SelectContent>
        </Select>
        <Select value={sortBy} onValueChange={v => setSortBy(v as typeof sortBy)}>
          <SelectTrigger className="w-full sm:w-32"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="date">By Date</SelectItem>
            <SelectItem value="cost">By Cost</SelectItem>
            <SelectItem value="kWh">By kWh</SelectItem>
          </SelectContent>
        </Select>

      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-muted-foreground">Totals</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <div className="rounded-lg bg-muted p-2 text-center">
              <p className="text-lg font-bold text-foreground">{totals.count}</p>
              <p className="text-xs text-muted-foreground">Sessions</p>
            </div>
            <div className="rounded-lg bg-muted p-2 text-center">
              <p className="text-lg font-bold text-foreground">{totals.kWh.toFixed(1)}</p>
              <p className="text-xs text-muted-foreground">Total kWh</p>
            </div>
            <div className="rounded-lg bg-muted p-2 text-center">
              <p className="text-lg font-bold text-foreground">{settings.currencySymbol}{totals.cost.toFixed(0)}</p>
              <p className="text-xs text-muted-foreground">Total Cost</p>
            </div>
            <div className="rounded-lg bg-muted p-2 text-center">
              <p className="text-lg font-bold text-foreground">
                {rangeSummary ? `${rangeSummary.total.toFixed(0)}` : '—'}
              </p>
              <p className="text-xs text-muted-foreground">Est. Range {settings.distanceUnit}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {rangeSummary && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">Estimated Range Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              <div className="rounded-lg bg-muted p-2 text-center">
                <p className="text-lg font-bold text-foreground">{rangeSummary.total.toFixed(0)}</p>
                <p className="text-xs text-muted-foreground">Total {settings.distanceUnit}</p>
              </div>
              <div className="rounded-lg bg-muted p-2 text-center">
                <p className="text-lg font-bold text-foreground">{rangeSummary.avg.toFixed(0)}</p>
                <p className="text-xs text-muted-foreground">Avg / session</p>
              </div>
              <div className="rounded-lg bg-muted p-2 text-center">
                <p className="text-lg font-bold text-foreground">{rangeSummary.min.toFixed(0)}</p>
                <p className="text-xs text-muted-foreground">Min</p>
              </div>
              <div className="rounded-lg bg-muted p-2 text-center">
                <p className="text-lg font-bold text-foreground">{rangeSummary.max.toFixed(0)}</p>
                <p className="text-xs text-muted-foreground">Max</p>
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Based on {rangeSummary.count} session{rangeSummary.count === 1 ? '' : 's'} with vehicle range data.
            </p>
          </CardContent>
        </Card>
      )}

      {filtered.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-8">
            <Zap className="h-12 w-12 text-muted-foreground" />
            <p className="text-muted-foreground">No sessions found</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map(session => {
            const vehicle = vehicles.find(v => v.id === session.vehicleId);
            const estRange = vehicle && vehicle.range && vehicle.batteryCapacity
              ? (session.kWh / vehicle.batteryCapacity) * vehicle.range
              : null;
            return (
              <Card key={session.id}>
                <CardContent className="flex items-start justify-between gap-3 p-4">
                  <div className="flex min-w-0 flex-1 items-start gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
                      <Zap className="h-5 w-5 text-primary" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium text-foreground">{session.location}</p>
                      <p className="text-xs text-muted-foreground break-words">
                        {vehicle?.name} · {format(new Date(session.date), 'MMM d, yyyy h:mm a')}
                      </p>
                      <p className="text-xs text-muted-foreground break-words">
                        {session.kWh} kWh · {settings.currencySymbol}{(session.cost / session.kWh).toFixed(1)}/kWh
                        {session.odometerReading > 0 && ` · ${session.odometerReading} ${settings.distanceUnit}`}
                      </p>
                      <div className="mt-1 flex flex-wrap gap-1">
                        <span
                          className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${
                            (session.locationType || 'home') === 'public'
                              ? 'bg-accent text-accent-foreground'
                              : 'bg-primary/10 text-primary'
                          }`}
                        >
                          {(session.locationType || 'home') === 'public' ? 'Public station' : 'Home'}
                        </span>
                        {vehicle?.range ? (
                          <span className="rounded-full bg-muted px-2 py-0.5 text-[10px] text-muted-foreground">
                            Range {vehicle.range} {settings.distanceUnit}
                          </span>
                        ) : null}
                        {session.batteryStart !== undefined && (
                          <span className="rounded-full bg-muted px-2 py-0.5 text-[10px] text-foreground">
                            {session.batteryEnd !== undefined
                              ? `Charged ${session.batteryStart}% → ${session.batteryEnd}% (+${(session.batteryEnd - session.batteryStart).toFixed(0)}%)`
                              : `Started at ${session.batteryStart}%`}
                          </span>
                        )}
                        {estRange !== null && (
                          <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[10px] text-primary">
                            ~{estRange.toFixed(0)} {settings.distanceUnit} added
                          </span>
                        )}
                      </div>

                    </div>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1">
                    <p className="text-lg font-bold text-foreground">{settings.currencySymbol}{session.cost.toFixed(0)}</p>
                    <div className="flex items-center">
                      <Button variant="ghost" size="icon" asChild>
                        <Link to={`/add-session?edit=${session.id}`}><Pencil className="h-4 w-4" /></Link>
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => { deleteSession(session.id); toast({ title: 'Deleted' }); }}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default ChargingHistory;
