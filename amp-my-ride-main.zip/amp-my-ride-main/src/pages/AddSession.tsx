import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useVehicles, useSessions, useSettings, useStationRates } from '@/hooks/useAppData';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Info, Lock, Unlock } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const AddSession = () => {
  const { vehicles } = useVehicles();
  const { sessions, addSession, updateSession } = useSessions();
  const { settings } = useSettings();
  const { stationRates, getStationRate, saveStationRate } = useStationRates();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchParams] = useSearchParams();
  const editId = searchParams.get('edit');

  const editSession = editId ? sessions.find(s => s.id === editId) : null;

  const [form, setForm] = useState({
    vehicleId: editSession?.vehicleId || '',
    date: (() => {
      const d = editSession?.date ? new Date(editSession.date) : new Date();
      const pad = (n: number) => String(n).padStart(2, '0');
      return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    })(),
    kWh: editSession?.kWh?.toString() || '',
    cost: editSession?.cost?.toString() || '',
    location: editSession?.location || '',
    locationType: editSession?.locationType || 'home' as 'home' | 'public',
    rate: (() => {
      if (editSession && editSession.kWh > 0) return (editSession.cost / editSession.kWh).toFixed(2);
      const t = editSession?.locationType || 'home';
      return String(t === 'public' ? settings.publicChargingRate : settings.electricityRate);
    })(),

    odometerReading: editSession?.odometerReading?.toString() || '',
    tripDistance: editSession?.tripDistance?.toString() || '',
    batteryStart: editSession?.batteryStart !== undefined ? String(editSession.batteryStart) : '',
    batteryEnd: editSession?.batteryEnd !== undefined ? String(editSession.batteryEnd) : '',
  });

  const [rememberRate, setRememberRate] = useState(true);
  const savedForStation = form.locationType === 'public' ? getStationRate(form.location) : undefined;

  const [tripDistanceManual, setTripDistanceManual] = useState(!!editSession?.tripDistance);
  const [showUnlockConfirm, setShowUnlockConfirm] = useState(false);

  const selectedVehicle = vehicles.find(v => v.id === form.vehicleId);

  const editSessionDate = editSession ? new Date(editSession.date).getTime() : null;
  const lastSession = form.vehicleId
    ? sessions
        .filter(s => {
          if (s.vehicleId !== form.vehicleId) return false;
          if (s.id === editId) return false;
          if (!s.odometerReading) return false;
          // When editing, use the session immediately before this one chronologically
          if (editSessionDate) return new Date(s.date).getTime() < editSessionDate;
          return true;
        })
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0]
    : null;
  const previousOdo = lastSession?.odometerReading || 0;
  const currentOdo = parseFloat(form.odometerReading) || 0;
  const autoTripDistance = previousOdo && currentOdo > previousOdo ? currentOdo - previousOdo : 0;
  const displayedTripDistance = tripDistanceManual
    ? (parseFloat(form.tripDistance) || 0)
    : autoTripDistance;

  const estimateKwh = (start: string, end: string, vehicleId: string) => {
    const vehicle = vehicles.find(v => v.id === vehicleId);
    if (!vehicle || !start || !end) return '';
    const s = parseFloat(start);
    const e = parseFloat(end);
    if (isNaN(s) || isNaN(e) || e <= s) return '';
    return ((e - s) / 100 * vehicle.batteryCapacity).toFixed(1);
  };

  const handleBatteryChange = (field: 'batteryStart' | 'batteryEnd', value: string) => {
    const num = parseFloat(value);
    if (value && (num < 0 || num > 100)) return;
    const updated = { ...form, [field]: value };
    const estimated = estimateKwh(
      field === 'batteryStart' ? value : form.batteryStart,
      field === 'batteryEnd' ? value : form.batteryEnd,
      form.vehicleId
    );
    if (estimated) {
      updated.kWh = estimated;
      const rate = parseFloat(form.rate);

      if (rate) {
        updated.cost = (parseFloat(estimated) * rate).toFixed(2);
      }
    }
    setForm(updated);
  };

  const costPerKwh = form.kWh && form.cost
    ? (parseFloat(form.cost) / parseFloat(form.kWh)).toFixed(2)
    : '—';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.vehicleId || !form.kWh || !form.cost) {
      toast({ title: 'Missing fields', description: 'Please fill in vehicle, kWh, and cost.', variant: 'destructive' });
      return;
    }

    const data = {
      vehicleId: form.vehicleId,
      date: new Date(form.date).toISOString(),
      kWh: parseFloat(form.kWh),
      cost: parseFloat(form.cost),
      location: form.location || (form.locationType === 'home' ? 'Home' : 'Public Station'),
      locationType: form.locationType as 'home' | 'public',
      odometerReading: parseFloat(form.odometerReading) || 0,
      tripDistance: tripDistanceManual ? (parseFloat(form.tripDistance) || 0) : autoTripDistance,
      batteryStart: form.batteryStart !== '' ? parseFloat(form.batteryStart) : undefined,
      batteryEnd: form.batteryEnd !== '' ? parseFloat(form.batteryEnd) : undefined,
    };

    if (form.locationType === 'public' && rememberRate && form.location.trim()) {
      const r = parseFloat(form.rate);
      if (r > 0) saveStationRate(form.location, r);
    }



    if (editId) {
      updateSession(editId, data);
      toast({ title: 'Session updated' });
    } else {
      addSession(data);
      toast({ title: 'Session added!' });
    }
    navigate('/history');
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-foreground">{editId ? 'Edit' : 'Add'} Charging Session</h1>

      {vehicles.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-8">
            <p className="text-muted-foreground">Add a vehicle first before logging sessions.</p>
            <Button onClick={() => navigate('/vehicles')}>Add Vehicle</Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Vehicle</Label>
                <Select value={form.vehicleId} onValueChange={v => setForm(p => ({ ...p, vehicleId: v }))}>
                  <SelectTrigger><SelectValue placeholder="Select vehicle" /></SelectTrigger>
                  <SelectContent>
                    {vehicles.map(v => (
                      <SelectItem key={v.id} value={v.id}>{v.name} ({v.make} {v.model})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Date & Time</Label>
                <Input
                  type="datetime-local"
                  value={form.date}
                  onChange={e => setForm(p => ({ ...p, date: e.target.value }))}
                />
              </div>

              {selectedVehicle && (
                <div className="rounded-lg border border-dashed border-primary/30 bg-primary/5 p-4 space-y-3">
                  <Label className="text-sm font-medium">Estimate kWh from Battery %</Label>
                  <p className="text-xs text-muted-foreground">
                    Based on {selectedVehicle.name}'s {selectedVehicle.batteryCapacity} kWh battery
                  </p>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label className="text-xs">Start %</Label>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        placeholder="e.g. 20"
                        value={form.batteryStart}
                        onChange={e => handleBatteryChange('batteryStart', e.target.value)}
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">End %</Label>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        placeholder="e.g. 80"
                        value={form.batteryEnd}
                        onChange={e => handleBatteryChange('batteryEnd', e.target.value)}
                      />
                    </div>
                  </div>
                  {form.batteryStart && form.batteryEnd && parseFloat(form.batteryEnd) > parseFloat(form.batteryStart) && (
                    <div className="space-y-2 pt-1">
                      <div className="relative h-8 w-full rounded-md border-2 border-muted-foreground/30 bg-muted/50 overflow-hidden">
                        {/* Charged range */}
                        <div
                          className="absolute top-0 bottom-0 bg-primary/30 transition-all duration-300"
                          style={{
                            left: `${parseFloat(form.batteryStart)}%`,
                            width: `${parseFloat(form.batteryEnd) - parseFloat(form.batteryStart)}%`,
                          }}
                        />
                        {/* Start marker */}
                        <div
                          className="absolute top-0 bottom-0 w-0.5 bg-destructive transition-all duration-300"
                          style={{ left: `${parseFloat(form.batteryStart)}%` }}
                        />
                        {/* End marker */}
                        <div
                          className="absolute top-0 bottom-0 w-0.5 bg-primary transition-all duration-300"
                          style={{ left: `${parseFloat(form.batteryEnd)}%` }}
                        />
                        {/* Battery tip */}
                        <div className="absolute right-[-6px] top-1/2 -translate-y-1/2 h-3 w-[6px] rounded-r-sm bg-muted-foreground/30" />
                        {/* Labels */}
                        <span className="absolute left-1 top-1/2 -translate-y-1/2 text-[10px] font-semibold text-destructive">
                          {form.batteryStart}%
                        </span>
                        <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] font-semibold text-primary">
                          {form.batteryEnd}%
                        </span>
                      </div>
                      <p className="text-center text-xs text-muted-foreground">
                        +{(parseFloat(form.batteryEnd) - parseFloat(form.batteryStart)).toFixed(0)}% ≈ {estimateKwh(form.batteryStart, form.batteryEnd, form.vehicleId)} kWh
                      </p>
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="flex items-center gap-1">
                    kWh Consumed
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger type="button" tabIndex={-1}>
                          <Info className="h-3.5 w-3.5 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent side="top" className="max-w-[220px] text-xs">
                          Find this on your charger display, charging app, or car dashboard after a session.
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </Label>
                  <Input
                    type="number"
                    step="0.1"
                    placeholder="e.g. 25.5"
                    value={form.kWh}
                    onChange={e => {
                      const kWh = e.target.value;
                      const rate = parseFloat(form.rate);
                      const estimatedCost = kWh && rate
                        ? (parseFloat(kWh) * rate).toFixed(2)
                        : '';
                      setForm(p => ({ ...p, kWh, cost: estimatedCost || p.cost }));
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Cost ({settings.currencySymbol})</Label>
                  <Input
                    type="number"
                    step="0.01"
                    placeholder="e.g. 200"
                    value={form.cost}
                    onChange={e => setForm(p => ({ ...p, cost: e.target.value }))}
                  />
                </div>
              </div>

              <div className="rounded-lg bg-muted p-3 text-center">
                <span className="text-sm text-muted-foreground">Cost per kWh: </span>
                <span className="font-semibold text-foreground">{settings.currencySymbol}{costPerKwh}</span>
              </div>

              <div className="space-y-2">
                <Label>Location Type</Label>
                <Select value={form.locationType} onValueChange={v => {
                  const locationType = v as 'home' | 'public';
                  const saved = locationType === 'public' ? getStationRate(form.location)?.rate : undefined;
                  const rate = saved ?? (locationType === 'public' ? settings.publicChargingRate : settings.electricityRate);
                  const cost = form.kWh && rate ? (parseFloat(form.kWh) * rate).toFixed(2) : form.cost;
                  setForm(p => ({ ...p, locationType, rate: rate ? String(rate) : '', cost }));
                }}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="home">Home</SelectItem>
                    <SelectItem value="public">Public Station</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Location Name</Label>
                <Input
                  list="saved-stations"
                  placeholder={form.locationType === 'home' ? 'Home' : 'Station name'}
                  value={form.location}
                  onChange={e => {
                    const location = e.target.value;
                    const saved = form.locationType === 'public' ? getStationRate(location)?.rate : undefined;
                    if (saved) {
                      const cost = form.kWh ? (parseFloat(form.kWh) * saved).toFixed(2) : form.cost;
                      setForm(p => ({ ...p, location, rate: String(saved), cost }));
                    } else {
                      setForm(p => ({ ...p, location }));
                    }
                  }}
                />
                <datalist id="saved-stations">
                  {stationRates.map(s => (
                    <option key={s.name} value={s.name} />
                  ))}
                </datalist>
                {form.locationType === 'public' && savedForStation && (
                  <p className="text-xs text-primary">
                    Saved rate for this station: {settings.currencySymbol}{savedForStation.rate}/kWh
                  </p>
                )}
              </div>

              <div className="space-y-2 rounded-lg border border-border p-3">
                <div className="flex items-center justify-between gap-2">
                  <Label>
                    {form.locationType === 'public' ? 'Station rate' : 'Home rate'} ({settings.currencySymbol}/kWh)
                  </Label>
                  {(() => {
                    const defaultRate = form.locationType === 'public' ? settings.publicChargingRate : settings.electricityRate;
                    return parseFloat(form.rate) !== defaultRate ? (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="h-7 px-2 text-xs"
                        onClick={() => {
                          const cost = form.kWh && defaultRate ? (parseFloat(form.kWh) * defaultRate).toFixed(2) : form.cost;
                          setForm(p => ({ ...p, rate: String(defaultRate), cost }));
                        }}
                      >
                        Reset to default
                      </Button>
                    ) : null;
                  })()}
                </div>
                <Input
                  type="number"
                  step="0.01"
                  inputMode="decimal"
                  placeholder="e.g. 18"
                  value={form.rate}
                  onChange={e => {
                    const rate = e.target.value;
                    const r = parseFloat(rate);
                    const cost = form.kWh && !isNaN(r) ? (parseFloat(form.kWh) * r).toFixed(2) : form.cost;
                    setForm(p => ({ ...p, rate, cost }));
                  }}
                />
                {form.locationType === 'public' && (
                  <div className="flex items-center gap-2 pt-1">
                    <Checkbox
                      id="remember-station-rate"
                      checked={rememberRate}
                      onCheckedChange={v => setRememberRate(v === true)}
                    />
                    <Label htmlFor="remember-station-rate" className="text-xs font-normal text-muted-foreground">
                      Remember this rate for this station
                    </Label>
                  </div>
                )}
                <p className="text-xs text-muted-foreground">
                  {form.locationType === 'public'
                    ? 'Each station can charge a different price — edit it here and it auto-fills next time.'
                    : 'Rate used to calculate this session cost.'}
                </p>
              </div>


              <div className="space-y-2">
                <Label>Odometer ({settings.distanceUnit})</Label>
                <Input
                  type="number"
                  placeholder="Current reading"
                  value={form.odometerReading}
                  onChange={e => setForm(p => ({ ...p, odometerReading: e.target.value }))}
                />
                {form.vehicleId && (
                  <div className="rounded-lg border border-dashed border-primary/30 bg-primary/5 p-3 text-xs space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Last odometer</span>
                      <span className="font-medium text-foreground">
                        {previousOdo ? `${previousOdo.toLocaleString()} ${settings.distanceUnit}` : '—'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">New odometer</span>
                      <span className="font-medium text-foreground">
                        {currentOdo ? `${currentOdo.toLocaleString()} ${settings.distanceUnit}` : '—'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 pt-1">
                      <div className="flex-1 space-y-1">
                        <Label className="text-xs text-muted-foreground">Trip since last charge</Label>
                        <Input
                          type="number"
                          readOnly={!tripDistanceManual}
                          placeholder={tripDistanceManual ? 'Enter trip distance' : 'Auto-calculated'}
                          value={tripDistanceManual ? form.tripDistance : (autoTripDistance || '')}
                          onChange={e => setForm(p => ({ ...p, tripDistance: e.target.value }))}
                          className={tripDistanceManual ? '' : 'bg-muted/50'}
                        />
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        className="mt-5 shrink-0"
                        onClick={() => {
                          if (tripDistanceManual) {
                            setTripDistanceManual(false);
                            setForm(p => ({ ...p, tripDistance: '' }));
                          } else {
                            setShowUnlockConfirm(true);
                          }
                        }}
                        title={tripDistanceManual ? 'Lock auto-calculation' : 'Override trip distance'}
                      >
                        {tripDistanceManual ? <Lock className="h-4 w-4" /> : <Unlock className="h-4 w-4" />}
                      </Button>
                    </div>
                    <p className="text-[10px] text-muted-foreground">
                      {tripDistanceManual
                        ? 'Manual override active. Odometer changes will not update this value.'
                        : 'Auto-calculated from new minus last odometer. Tap the lock to override.'}
                    </p>
                  </div>
                )}
              </div>

              <div className="flex gap-3 pt-2">
                <Button type="submit" className="flex-1">{editId ? 'Update' : 'Add'} Session</Button>
                <Button type="button" variant="outline" onClick={() => navigate(-1)}>Cancel</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <AlertDialog open={showUnlockConfirm} onOpenChange={setShowUnlockConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Override trip distance?</AlertDialogTitle>
            <AlertDialogDescription>
              The trip distance is currently auto-calculated from your odometer readings. Switching to manual will let you enter your own value, but the auto-calculated value will no longer update when the odometer changes.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setShowUnlockConfirm(false)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => {
              setTripDistanceManual(true);
              setForm(p => ({ ...p, tripDistance: autoTripDistance ? autoTripDistance.toString() : '' }));
              setShowUnlockConfirm(false);
            }}>
              Override
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default AddSession;
