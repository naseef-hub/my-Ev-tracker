import { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Gauge, Trash2, Plus } from 'lucide-react';
import { useTrips, useVehicles, useSettings } from '@/hooks/useAppData';
import { tripEnergy, fleetEfficiency } from '@/lib/tripStats';
import { toast } from '@/hooks/use-toast';

export default function TripLog() {
  const { trips, addTrip, deleteTrip } = useTrips();
  const { vehicles } = useVehicles();
  const { settings } = useSettings();

  const [vehicleId, setVehicleId] = useState(vehicles[0]?.id ?? '');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [label, setLabel] = useState('');
  const [odoStart, setOdoStart] = useState('');
  const [odoEnd, setOdoEnd] = useState('');
  const [energy, setEnergy] = useState('');
  const [battStart, setBattStart] = useState('');
  const [battEnd, setBattEnd] = useState('');
  const [notes, setNotes] = useState('');

  const vehicle = vehicles.find(v => v.id === vehicleId) ?? vehicles[0];
  const unit = settings.distanceUnit;

  const previewDistance = (parseFloat(odoEnd) || 0) - (parseFloat(odoStart) || 0);

  const sortedTrips = useMemo(
    () => [...trips].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
    [trips]
  );

  const summary = useMemo(() => fleetEfficiency(trips, vehicles, vehicle?.id), [trips, vehicles, vehicle?.id]);

  const reset = () => {
    setLabel('');
    setOdoStart('');
    setOdoEnd('');
    setEnergy('');
    setBattStart('');
    setBattEnd('');
    setNotes('');
  };

  const handleSave = () => {
    const start = parseFloat(odoStart);
    const end = parseFloat(odoEnd);
    if (!vehicle) {
      toast({ title: 'Add a vehicle first', variant: 'destructive' });
      return;
    }
    if (isNaN(start) || isNaN(end) || end <= start) {
      toast({ title: 'Check the odometer', description: 'The end reading must be higher than the start.', variant: 'destructive' });
      return;
    }
    addTrip({
      vehicleId: vehicle.id,
      date: new Date(date).toISOString(),
      label: label.trim() || undefined,
      odometerStart: start,
      odometerEnd: end,
      energyUsed: energy ? parseFloat(energy) : undefined,
      batteryStart: battStart ? parseFloat(battStart) : undefined,
      batteryEnd: battEnd ? parseFloat(battEnd) : undefined,
      notes: notes.trim() || undefined,
    });
    toast({ title: 'Trip saved', description: `${(end - start).toFixed(0)} ${unit} recorded.` });
    reset();
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Trip log</h1>
        <p className="text-sm text-muted-foreground">
          Record the odometer before and after a drive. The trip planner uses this real driving data instead of an average.
        </p>
      </div>

      {summary && (
        <Card className="border-primary/30 bg-primary/5">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Your real mileage{vehicle ? ` — ${vehicle.name}` : ''}</p>
            <p className="text-3xl font-bold text-primary">
              {summary.kmPerKWh.toFixed(1)} {unit}/kWh
            </p>
            <p className="text-sm text-muted-foreground">
              from {summary.tripCount} trip{summary.tripCount > 1 ? 's' : ''} · {summary.distance.toFixed(0)} {unit} ·{' '}
              {summary.energy.toFixed(1)} kWh used
            </p>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Gauge className="h-4 w-4" /> Record a trip
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="space-y-1">
              <Label className="text-xs">Vehicle</Label>
              <Select value={vehicle?.id ?? ''} onValueChange={setVehicleId}>
                <SelectTrigger><SelectValue placeholder="Select vehicle" /></SelectTrigger>
                <SelectContent>
                  {vehicles.map(v => <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Date</Label>
              <Input type="date" value={date} onChange={e => setDate(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Trip name (optional)</Label>
              <Input value={label} onChange={e => setLabel(e.target.value)} placeholder="Delhi to Jaipur" />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="space-y-1">
              <Label className="text-xs">Odometer start ({unit})</Label>
              <Input type="number" value={odoStart} onChange={e => setOdoStart(e.target.value)} placeholder="12000" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Odometer end ({unit})</Label>
              <Input type="number" value={odoEnd} onChange={e => setOdoEnd(e.target.value)} placeholder="12280" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Distance</Label>
              <div className="flex h-10 items-center rounded-md border border-border bg-muted/40 px-3 text-sm font-medium">
                {previewDistance > 0 ? `${previewDistance.toFixed(0)} ${unit}` : '—'}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="space-y-1">
              <Label className="text-xs">Energy used (kWh, optional)</Label>
              <Input type="number" step="0.1" value={energy} onChange={e => setEnergy(e.target.value)} placeholder="45" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Battery % at start</Label>
              <Input type="number" min="0" max="100" value={battStart} onChange={e => setBattStart(e.target.value)} placeholder="100" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Battery % at end</Label>
              <Input type="number" min="0" max="100" value={battEnd} onChange={e => setBattEnd(e.target.value)} placeholder="25" />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            Enter either the energy used or the battery percentage before and after — that is how your real mileage is worked out.
          </p>

          <div className="space-y-1">
            <Label className="text-xs">Notes (optional)</Label>
            <Textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="Highway, AC on, 3 passengers" rows={2} />
          </div>

          <Button onClick={handleSave} className="w-full gap-2">
            <Plus className="h-4 w-4" /> Save trip
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Past trips</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {sortedTrips.length === 0 && (
            <p className="py-6 text-center text-sm text-muted-foreground">No trips recorded yet.</p>
          )}
          {sortedTrips.map(t => {
            const v = vehicles.find(x => x.id === t.vehicleId);
            const distance = t.odometerEnd - t.odometerStart;
            const used = tripEnergy(t, v);
            return (
              <div key={t.id} className="flex items-start justify-between gap-3 rounded-lg border border-border p-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-foreground">
                    {t.label || `${t.odometerStart.toFixed(0)} → ${t.odometerEnd.toFixed(0)}`}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(t.date).toLocaleDateString()} · {v?.name ?? 'Vehicle'} · {distance.toFixed(0)} {unit}
                  </p>
                  <div className="mt-1 flex flex-wrap gap-1.5">
                    {used ? (
                      <Badge variant="secondary">{used.toFixed(1)} kWh used</Badge>
                    ) : (
                      <Badge variant="outline">energy not recorded</Badge>
                    )}
                    {used && distance > 0 && (
                      <Badge>{(distance / used).toFixed(1)} {unit}/kWh</Badge>
                    )}
                    {t.batteryStart != null && t.batteryEnd != null && (
                      <Badge variant="outline">{t.batteryStart}% → {t.batteryEnd}%</Badge>
                    )}
                  </div>
                  {t.notes && <p className="mt-1 text-xs text-muted-foreground">{t.notes}</p>}
                </div>
                <Button variant="ghost" size="icon" onClick={() => deleteTrip(t.id)} aria-label="Delete trip">
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}
