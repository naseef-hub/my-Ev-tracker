import { useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useSettings } from '@/hooks/useAppData';
import { useToast } from '@/hooks/use-toast';
import { Download, Upload, Trash2 } from 'lucide-react';
import { StationPrices } from '@/components/StationPrices';



const CURRENCIES = [
  { code: 'INR', symbol: '₹' },
  { code: 'USD', symbol: '$' },
  { code: 'EUR', symbol: '€' },
  { code: 'GBP', symbol: '£' },
  { code: 'AUD', symbol: 'A$' },
];

const SettingsPage = () => {
  const { settings, setSettings } = useSettings();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const exportData = () => {
    const data = {
      vehicles: localStorage.getItem('ev-vehicles'),
      sessions: localStorage.getItem('ev-sessions'),
      settings: localStorage.getItem('ev-settings'),
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ev-tracker-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: 'Backup exported!' });
  };

  const importData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const raw = ev.target?.result as string;
        const data = JSON.parse(raw);

        // Accept either: { vehicles: "<json string>", ... } (legacy export)
        // or: { vehicles: [...], sessions: [...], settings: {...} } (object form)
        const normalize = (v: unknown) =>
          typeof v === 'string' ? v : v != null ? JSON.stringify(v) : null;

        const vehicles = normalize(data.vehicles);
        const sessions = normalize(data.sessions);
        const settings = normalize(data.settings);

        if (!vehicles && !sessions && !settings) {
          throw new Error('No recognizable data in backup file');
        }

        if (vehicles) localStorage.setItem('ev-vehicles', vehicles);
        if (sessions) localStorage.setItem('ev-sessions', sessions);
        if (settings) localStorage.setItem('ev-settings', settings);

        toast({ title: 'Data restored! Reloading...' });
        setTimeout(() => window.location.reload(), 1000);
      } catch (err) {
        console.error('Import failed:', err);
        toast({
          title: 'Invalid backup file',
          description: err instanceof Error ? err.message : 'Could not parse file',
          variant: 'destructive',
        });
      } finally {
        // Reset so selecting the same file again still triggers onChange
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.onerror = () => {
      toast({ title: 'Could not read file', variant: 'destructive' });
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    reader.readAsText(file);
  };

  const clearAllData = () => {
    ['ev-vehicles', 'ev-sessions', 'ev-station-rates'].forEach(k => localStorage.removeItem(k));
    toast({ title: 'All data cleared', description: 'Reloading...' });
    setTimeout(() => window.location.reload(), 800);
  };

  return (

    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-foreground">Settings</h1>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Preferences</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Currency</Label>
            <Select
              value={settings.currency}
              onValueChange={v => {
                const c = CURRENCIES.find(c => c.code === v);
                if (c) setSettings(prev => ({ ...prev, currency: c.code, currencySymbol: c.symbol }));
              }}
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {CURRENCIES.map(c => (
                  <SelectItem key={c.code} value={c.code}>{c.symbol} {c.code}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Distance Unit</Label>
            <Select value={settings.distanceUnit} onValueChange={v => setSettings(prev => ({ ...prev, distanceUnit: v as 'km' | 'miles' }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="km">Kilometers (km)</SelectItem>
                <SelectItem value="miles">Miles</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Home Electricity Rate ({settings.currencySymbol}/kWh)</Label>
            <Input
              type="number"
              step="0.1"
              value={settings.electricityRate}
              onChange={e => setSettings(prev => ({ ...prev, electricityRate: parseFloat(e.target.value) || 0 }))}
            />
            <p className="text-xs text-muted-foreground">Used to estimate home charging costs</p>
          </div>

          <div className="space-y-2">
            <Label>Public Charging Rate ({settings.currencySymbol}/kWh)</Label>
            <Input
              type="number"
              step="0.1"
              value={settings.publicChargingRate}
              onChange={e => setSettings(prev => ({ ...prev, publicChargingRate: parseFloat(e.target.value) || 0 }))}
            />
            <p className="text-xs text-muted-foreground">Used to estimate public station charging costs</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Data Backup</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            Export your data as a JSON file for backup, or import a previously exported backup.
          </p>
          <div className="flex gap-3">
            <Button onClick={exportData} variant="outline" className="flex-1">
              <Download className="h-4 w-4" /> Export Backup
            </Button>
            <Button onClick={() => fileInputRef.current?.click()} variant="outline" className="flex-1">
              <Upload className="h-4 w-4" /> Import Backup
            </Button>
            <input ref={fileInputRef} type="file" accept=".json" onChange={importData} className="hidden" />
          </div>
        </CardContent>
      </Card>

      <StationPrices />



      <Card className="border-destructive/40">
        <CardHeader>
          <CardTitle className="text-base text-destructive">Clear Data</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            Permanently delete all vehicles, charging sessions and saved station rates from this device. Export a backup first if you may need it later.
          </p>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" className="w-full">
                <Trash2 className="h-4 w-4" /> Clear All Data
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete everything?</AlertDialogTitle>
                <AlertDialogDescription>
                  This removes all vehicles, sessions and saved station rates. This cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={clearAllData}>Yes, clear all</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>
    </div>
  );
};


export default SettingsPage;
