import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Zap, TrendingUp, MapPin, Car, Gauge, Settings2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useVehicles, useSessions, useSettings } from '@/hooks/useAppData';
import { QuickAddSession } from '@/components/QuickAddSession';
import { NearbyStations } from '@/components/NearbyStations';
import { HomeSavingsCard } from '@/components/HomeSavingsCard';
import { useToast } from '@/hooks/use-toast';
import { format, startOfMonth, isAfter } from 'date-fns';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, LineChart, Line, ReferenceLine, Legend } from 'recharts';

const Dashboard = () => {
  const { vehicles, updateVehicle } = useVehicles();
  const { sessions } = useSessions();
  const { settings } = useSettings();
  const { toast } = useToast();
  const [configVehicleId, setConfigVehicleId] = useState<string | null>(null);
  const [configForm, setConfigForm] = useState({ batteryCapacity: '', range: '' });

  const openConfig = (id: string) => {
    const v = vehicles.find(x => x.id === id);
    if (!v) return;
    setConfigForm({
      batteryCapacity: v.batteryCapacity ? String(v.batteryCapacity) : '',
      range: v.range ? String(v.range) : '',
    });
    setConfigVehicleId(id);
  };

  const saveConfig = () => {
    if (!configVehicleId) return;
    updateVehicle(configVehicleId, {
      batteryCapacity: parseFloat(configForm.batteryCapacity) || 0,
      range: parseFloat(configForm.range) || 0,
    });
    toast({ title: 'Vehicle specs updated' });
    setConfigVehicleId(null);
  };

  const configVehicle = vehicles.find(v => v.id === configVehicleId);

  const monthStart = startOfMonth(new Date());

  const stats = useMemo(() => {
    const thisMonth = sessions.filter(s => isAfter(new Date(s.date), monthStart));
    const totalSpend = thisMonth.reduce((sum, s) => sum + s.cost, 0);
    const totalKwh = thisMonth.reduce((sum, s) => sum + s.kWh, 0);

    // Calculate cost per km from sessions with odometer data
    const sortedSessions = [...sessions].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    let totalDistance = 0;
    let totalCostForDistance = 0;
    for (let i = 1; i < sortedSessions.length; i++) {
      if (sortedSessions[i].vehicleId === sortedSessions[i - 1].vehicleId) {
        const dist = sortedSessions[i].odometerReading - sortedSessions[i - 1].odometerReading;
        if (dist > 0) {
          totalDistance += dist;
          totalCostForDistance += sortedSessions[i].cost;
        }
      }
    }
    const costPerKm = totalDistance > 0 ? totalCostForDistance / totalDistance : 0;

    return { totalSpend, totalKwh, costPerKm, sessionCount: thisMonth.length };
  }, [sessions, monthStart]);

  // Per-vehicle mileage from odometer readings
  const vehicleMileage = useMemo(() => {
    return vehicles.map(v => {
      const vSessions = sessions
        .filter(s => s.vehicleId === v.id)
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      let distance = 0;
      let energy = 0;
      let cost = 0;
      let lastTripDistance = 0;
      let previousOdo = 0;
      for (let i = 1; i < vSessions.length; i++) {
        const d = vSessions[i].odometerReading - vSessions[i - 1].odometerReading;
        if (d > 0) {
          distance += d;
          energy += vSessions[i - 1].kWh;
          cost += vSessions[i - 1].cost;
          lastTripDistance = d;
          previousOdo = vSessions[i - 1].odometerReading;
        }
      }
      const latestOdo = vSessions.length ? vSessions[vSessions.length - 1].odometerReading : 0;
      const kmPerKwh = energy > 0 ? distance / energy : 0;
      const costPerUnit = distance > 0 ? cost / distance : 0;
      // Actual range per full charge based on real usage
      const actualRangePerFullCharge = kmPerKwh * (v.batteryCapacity || 0);
      const claimedRange = v.range || 0;
      const efficiencyPct = claimedRange > 0 && actualRangePerFullCharge > 0
        ? (actualRangePerFullCharge / claimedRange) * 100
        : 0;
      return {
        vehicle: v, distance, energy, kmPerKwh, costPerUnit, latestOdo, previousOdo,
        lastTripDistance, actualRangePerFullCharge, claimedRange, efficiencyPct,
        hasData: distance > 0,
      };
    });
  }, [vehicles, sessions]);

  // Per-trip efficiency % over time (actual range vs claimed range)
  const efficiencyTrend = useMemo(() => {
    type Pt = { date: string; label: string } & Record<string, number | string>;
    const pointsByDate = new Map<string, Pt>();
    const vehiclesWithRange = vehicles.filter(v => (v.range || 0) > 0 && (v.batteryCapacity || 0) > 0);
    vehiclesWithRange.forEach(v => {
      const vSessions = sessions
        .filter(s => s.vehicleId === v.id)
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      for (let i = 1; i < vSessions.length; i++) {
        const d = vSessions[i].odometerReading - vSessions[i - 1].odometerReading;
        const kwh = vSessions[i - 1].kWh;
        if (d > 0 && kwh > 0) {
          const kmPerKwh = d / kwh;
          const actualRange = kmPerKwh * v.batteryCapacity;
          const pct = (actualRange / (v.range as number)) * 100;
          const iso = vSessions[i].date;
          const key = iso.slice(0, 10);
          if (!pointsByDate.has(key)) {
            pointsByDate.set(key, { date: key, label: format(new Date(iso), 'MMM d') });
          }
          (pointsByDate.get(key) as Pt)[v.id] = Math.round(pct);
        }
      }
    });
    const data = Array.from(pointsByDate.values()).sort((a, b) => (a.date as string).localeCompare(b.date as string));
    return { data, vehiclesWithRange };
  }, [vehicles, sessions]);

  // Per-vehicle efficiency summary stats (avg, best, worst)
  const vehicleEfficiencyStats = useMemo(() => {
    const statsMap = new Map<string, { avg: number; best: number; worst: number; trips: number }>();
    vehicles.forEach(v => {
      if ((v.range || 0) === 0 || (v.batteryCapacity || 0) === 0) return;
      const vSessions = sessions
        .filter(s => s.vehicleId === v.id)
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      const pcts: number[] = [];
      for (let i = 1; i < vSessions.length; i++) {
        const d = vSessions[i].odometerReading - vSessions[i - 1].odometerReading;
        const kwh = vSessions[i - 1].kWh;
        if (d > 0 && kwh > 0) {
          const kmPerKwh = d / kwh;
          const actualRange = kmPerKwh * v.batteryCapacity;
          const pct = (actualRange / (v.range as number)) * 100;
          pcts.push(pct);
        }
      }
      if (pcts.length > 0) {
        const avg = pcts.reduce((a, b) => a + b, 0) / pcts.length;
        statsMap.set(v.id, {
          avg,
          best: Math.max(...pcts),
          worst: Math.min(...pcts),
          trips: pcts.length,
        });
      }
    });
    return statsMap;
  }, [vehicles, sessions]);

  const chartData = useMemo(() => {
    const last7Days: Record<string, number> = {};
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      last7Days[format(d, 'EEE')] = 0;
    }
    sessions.forEach(s => {
      const d = new Date(s.date);
      const now = new Date();
      const diff = Math.floor((now.getTime() - d.getTime()) / (1000 * 60 * 60 * 24));
      if (diff < 7) {
        const key = format(d, 'EEE');
        if (key in last7Days) last7Days[key] += s.cost;
      }
    });
    return Object.entries(last7Days).map(([day, cost]) => ({ day, cost: Math.round(cost * 100) / 100 }));
  }, [sessions]);

  const recentSessions = useMemo(() => {
    return [...sessions]
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 5);
  }, [sessions]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
          <p className="text-sm text-muted-foreground">{format(new Date(), 'MMMM yyyy')}</p>
        </div>
        <div className="flex items-center gap-2">
          <QuickAddSession />
          <Button asChild>
            <Link to="/add-session">
              <Plus className="h-4 w-4" /> Full Form
            </Link>
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <TrendingUp className="h-4 w-4" />
              <span className="text-xs">Spent</span>
            </div>
            <p className="mt-1 text-2xl font-bold text-foreground">
              {settings.currencySymbol}{stats.totalSpend.toFixed(0)}
            </p>
            <p className="text-xs text-muted-foreground">this month</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Zap className="h-4 w-4" />
              <span className="text-xs">Energy</span>
            </div>
            <p className="mt-1 text-2xl font-bold text-foreground">
              {stats.totalKwh.toFixed(1)}
            </p>
            <p className="text-xs text-muted-foreground">kWh this month</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <MapPin className="h-4 w-4" />
              <span className="text-xs">Cost/{settings.distanceUnit}</span>
            </div>
            <p className="mt-1 text-2xl font-bold text-foreground">
              {settings.currencySymbol}{stats.costPerKm.toFixed(1)}
            </p>
            <p className="text-xs text-muted-foreground">average</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Car className="h-4 w-4" />
              <span className="text-xs">Sessions</span>
            </div>
            <p className="mt-1 text-2xl font-bold text-foreground">{stats.sessionCount}</p>
            <p className="text-xs text-muted-foreground">this month</p>
          </CardContent>
        </Card>
      </div>

      {/* Vehicle Mileage (from odometer) */}
      {vehicles.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <Gauge className="h-4 w-4 text-primary" /> Vehicle Mileage
              </CardTitle>
              <span className="text-xs text-muted-foreground">from odometer</span>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {vehicleMileage.map(({ vehicle, distance, kmPerKwh, costPerUnit, latestOdo, previousOdo, lastTripDistance, actualRangePerFullCharge, claimedRange, efficiencyPct, hasData }) => (
                <div key={vehicle.id} className="rounded-lg border border-border p-3 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{vehicle.name}</p>
                      <p className="text-xs text-muted-foreground">
                        Current: <span className="text-foreground font-medium">{latestOdo.toLocaleString()}</span> {settings.distanceUnit}
                      </p>
                      {hasData && (
                        <p className="text-xs text-muted-foreground">
                          Previous: {previousOdo.toLocaleString()} {settings.distanceUnit} · Last trip: {lastTripDistance.toFixed(0)} {settings.distanceUnit}
                        </p>
                      )}
                    </div>
                    <div className="flex items-start gap-2 shrink-0">
                      {hasData ? (
                        <div className="flex flex-col items-end">
                          <p className="text-sm font-semibold text-foreground">
                            {kmPerKwh.toFixed(2)} {settings.distanceUnit}/kWh
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {settings.currencySymbol}{costPerUnit.toFixed(2)}/{settings.distanceUnit} · {distance.toFixed(0)} {settings.distanceUnit} total
                          </p>
                        </div>
                      ) : (
                        <span className="text-xs text-muted-foreground">Need 2+ sessions</span>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => openConfig(vehicle.id)}
                        aria-label="Configure vehicle specs"
                        title="Configure rated range / battery"
                      >
                        <Settings2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                  {(!vehicle.batteryCapacity || !vehicle.range) && (
                    <button
                      type="button"
                      onClick={() => openConfig(vehicle.id)}
                      className="w-full rounded-md border border-dashed border-border bg-muted/30 px-2 py-1.5 text-left text-xs text-muted-foreground hover:bg-muted/50"
                    >
                      {!vehicle.batteryCapacity && !vehicle.range
                        ? 'Set battery capacity and rated range for accurate efficiency %'
                        : !vehicle.batteryCapacity
                        ? 'Set battery capacity (kWh) for accurate efficiency %'
                        : 'Set rated range for efficiency % comparison'}
                    </button>
                  )}
                  {hasData && claimedRange > 0 && (
                    <div className="flex flex-wrap items-center gap-2 rounded-md bg-muted/50 px-2 py-1.5 text-xs">
                      <span className="text-muted-foreground">Claimed:</span>
                      <span className="font-medium text-foreground">{claimedRange} {settings.distanceUnit}</span>
                      <span className="text-muted-foreground">· Actual:</span>
                      <span className="font-medium text-foreground">{actualRangePerFullCharge.toFixed(0)} {settings.distanceUnit}</span>
                      <span className={`ml-auto rounded-full px-2 py-0.5 font-semibold ${efficiencyPct >= 90 ? 'bg-primary/15 text-primary' : efficiencyPct >= 70 ? 'bg-muted text-foreground' : 'bg-destructive/15 text-destructive'}`}>
                        {efficiencyPct.toFixed(0)}% of rated
                      </span>
                    </div>
                  )}
                  {hasData && claimedRange === 0 && actualRangePerFullCharge > 0 && (
                    <p className="text-xs text-muted-foreground">
                      Actual range per full charge: <span className="font-medium text-foreground">{actualRangePerFullCharge.toFixed(0)} {settings.distanceUnit}</span> · set claimed range on the vehicle to compare
                    </p>
                  )}
                </div>
              ))}
            </div>

            {/* Efficiency over time */}
            {efficiencyTrend.vehiclesWithRange.length > 0 && (
              <div className="mt-4 border-t border-border pt-3">
                <div className="mb-2 flex items-center justify-between">
                  <p className="text-xs font-medium text-foreground">Range Efficiency Over Time</p>
                  <span className="text-[10px] text-muted-foreground">100% = rated range</span>
                </div>
                {efficiencyTrend.data.length < 2 ? (
                  <div className="flex h-32 items-center justify-center text-xs text-muted-foreground">
                    Need at least 2 trips with odometer readings
                  </div>
                ) : (
                  <>
                    {/* Summary stats per vehicle */}
                    <div className="mb-3 grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
                      {efficiencyTrend.vehiclesWithRange.map(v => {
                        const s = vehicleEfficiencyStats.get(v.id);
                        if (!s) return null;
                        return (
                          <div key={v.id} className="rounded-md border border-border p-2.5">
                            <p className="text-xs font-medium text-foreground truncate">{v.name}</p>
                            <div className="mt-1.5 flex items-center gap-3 text-[11px]">
                              <div>
                                <span className="text-muted-foreground">Avg:</span>
                                <span className={`ml-1 font-semibold ${s.avg >= 90 ? 'text-primary' : s.avg >= 70 ? 'text-foreground' : 'text-destructive'}`}>
                                  {s.avg.toFixed(0)}%
                                </span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Best:</span>
                                <span className="ml-1 font-semibold text-primary">{s.best.toFixed(0)}%</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Worst:</span>
                                <span className="ml-1 font-semibold text-destructive">{s.worst.toFixed(0)}%</span>
                              </div>
                            </div>
                            <p className="mt-1 text-[10px] text-muted-foreground">{s.trips} trip{s.trips > 1 ? 's' : ''}</p>
                          </div>
                        );
                      })}
                    </div>
                    <div className="h-40">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={efficiencyTrend.data} margin={{ top: 5, right: 8, left: -16, bottom: 0 }}>
                        <XAxis dataKey="label" tick={{ fontSize: 10 }} tickLine={false} axisLine={false} />
                        <YAxis tick={{ fontSize: 10 }} tickLine={false} axisLine={false} width={36} unit="%" domain={[0, 'auto']} />
                        <Tooltip
                          formatter={(value: number) => [`${value}%`, 'Efficiency']}
                          contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))', fontSize: '12px' }}
                        />
                        <ReferenceLine y={100} stroke="hsl(var(--muted-foreground))" strokeDasharray="3 3" />
                        {efficiencyTrend.vehiclesWithRange.map((v, idx) => (
                          <Line
                            key={v.id}
                            type="monotone"
                            dataKey={v.id}
                            name={v.name}
                            stroke={idx === 0 ? 'hsl(var(--primary))' : `hsl(${(idx * 70) % 360} 70% 50%)`}
                            strokeWidth={2}
                            dot={{ r: 3 }}
                            connectNulls
                          />
                        ))}
                        {efficiencyTrend.vehiclesWithRange.length > 1 && (
                          <Legend wrapperStyle={{ fontSize: '11px' }} />
                        )}
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  </>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Spending Chart */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Spending (Last 7 Days)</CardTitle>
        </CardHeader>
        <CardContent>
          {sessions.length === 0 ? (
            <div className="flex h-32 items-center justify-center text-sm text-muted-foreground">
              No data yet. Add your first charging session!
            </div>
          ) : (
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <XAxis dataKey="day" tick={{ fontSize: 12 }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 12 }} tickLine={false} axisLine={false} width={40} />
                  <Tooltip
                    formatter={(value: number) => [`${settings.currencySymbol}${value}`, 'Cost']}
                    contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))' }}
                  />
                  <Bar dataKey="cost" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Home vs Public Savings */}
      <HomeSavingsCard />

      {/* Nearby Charging Stations */}
      <NearbyStations />

      {/* Recent Sessions */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Recent Sessions</CardTitle>
            <Button variant="ghost" size="sm" asChild>
              <Link to="/history">View All</Link>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {recentSessions.length === 0 ? (
            <div className="flex h-24 items-center justify-center text-sm text-muted-foreground">
              No sessions yet
            </div>
          ) : (
            <div className="space-y-3">
              {recentSessions.map(session => {
                const vehicle = vehicles.find(v => v.id === session.vehicleId);
                return (
                  <div key={session.id} className="flex items-center justify-between rounded-lg border border-border p-3">
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10">
                        <Zap className="h-4 w-4 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <p className="truncate text-sm font-medium text-foreground">{session.location}</p>
                          <span className={`rounded-full px-1.5 py-0.5 text-[10px] font-medium ${
                            (session.locationType || 'home') === 'public'
                              ? 'bg-accent text-accent-foreground'
                              : 'bg-primary/10 text-primary'
                          }`}>
                            {(session.locationType || 'home') === 'public' ? 'Public' : 'Home'}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {vehicle?.name || 'Unknown'} · {format(new Date(session.date), 'MMM d')}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold text-foreground">
                        {settings.currencySymbol}{session.cost.toFixed(0)}
                      </p>
                      <p className="text-xs text-muted-foreground">{session.kWh} kWh</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
      <Dialog open={!!configVehicleId} onOpenChange={o => !o && setConfigVehicleId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Configure {configVehicle?.name || 'Vehicle'}</DialogTitle>
            <DialogDescription>
              Set battery capacity and rated range so efficiency % is calculated against your manufacturer's claim.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <div className="space-y-2">
              <Label>Battery Capacity (kWh)</Label>
              <Input
                type="number"
                inputMode="decimal"
                placeholder="e.g. 30"
                value={configForm.batteryCapacity}
                onChange={e => setConfigForm(p => ({ ...p, batteryCapacity: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label>Rated Range per full charge ({settings.distanceUnit})</Label>
              <Input
                type="number"
                inputMode="decimal"
                placeholder="e.g. 320"
                value={configForm.range}
                onChange={e => setConfigForm(p => ({ ...p, range: e.target.value }))}
              />
              <p className="text-xs text-muted-foreground">Manufacturer-claimed range (100% = this value).</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setConfigVehicleId(null)}>Cancel</Button>
              <Button className="flex-1" onClick={saveConfig}>Save</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Dashboard;
