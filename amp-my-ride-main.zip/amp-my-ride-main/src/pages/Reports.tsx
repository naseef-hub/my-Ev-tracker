import { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useVehicles, useSessions, useSettings } from '@/hooks/useAppData';
import { format, startOfMonth, subMonths } from 'date-fns';
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, ResponsiveContainer, Tooltip, Legend
} from 'recharts';

const COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

const Reports = () => {
  const { vehicles } = useVehicles();
  const { sessions } = useSessions();
  const { settings } = useSettings();

  const monthlySummary = useMemo(() => {
    const months: Record<string, { cost: number; kWh: number; count: number }> = {};
    for (let i = 5; i >= 0; i--) {
      const m = format(subMonths(new Date(), i), 'MMM yyyy');
      months[m] = { cost: 0, kWh: 0, count: 0 };
    }
    sessions.forEach(s => {
      const m = format(new Date(s.date), 'MMM yyyy');
      if (m in months) {
        months[m].cost += s.cost;
        months[m].kWh += s.kWh;
        months[m].count++;
      }
    });
    return Object.entries(months).map(([month, data]) => ({ month: month.split(' ')[0], ...data }));
  }, [sessions]);

  const locationData = useMemo(() => {
    let home = 0, pub = 0;
    sessions.forEach(s => {
      if (s.locationType === 'home') home += s.cost;
      else pub += s.cost;
    });
    return [
      { name: 'Home', value: Math.round(home) },
      { name: 'Public', value: Math.round(pub) },
    ].filter(d => d.value > 0);
  }, [sessions]);

  const costComparison = useMemo(() => {
    let homeKWh = 0, homeCost = 0, homeCount = 0;
    let pubKWh = 0, pubCost = 0, pubCount = 0;
    sessions.forEach(s => {
      if (s.locationType === 'home') { homeKWh += s.kWh; homeCost += s.cost; homeCount++; }
      else { pubKWh += s.kWh; pubCost += s.cost; pubCount++; }
    });
    return [
      { type: 'Home', sessions: homeCount, kWh: Math.round(homeKWh * 10) / 10, cost: Math.round(homeCost), avgRate: homeKWh > 0 ? Math.round(homeCost / homeKWh * 10) / 10 : 0 },
      { type: 'Public', sessions: pubCount, kWh: Math.round(pubKWh * 10) / 10, cost: Math.round(pubCost), avgRate: pubKWh > 0 ? Math.round(pubCost / pubKWh * 10) / 10 : 0 },
    ];
  }, [sessions]);

  const vehicleComparison = useMemo(() => {
    return vehicles.map(v => {
      const vs = sessions.filter(s => s.vehicleId === v.id);
      return {
        name: v.name,
        cost: Math.round(vs.reduce((sum, s) => sum + s.cost, 0)),
        kWh: Math.round(vs.reduce((sum, s) => sum + s.kWh, 0)),
      };
    }).filter(v => v.cost > 0 || v.kWh > 0);
  }, [vehicles, sessions]);
  if (sessions.length === 0) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-foreground">Reports & Analytics</h1>
        <Card>
          <CardContent className="flex h-48 items-center justify-center">
            <p className="text-muted-foreground">Add charging sessions to see reports</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-foreground">Reports & Analytics</h1>

      {/* Monthly Cost */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Monthly Spending</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlySummary}>
                <XAxis dataKey="month" tick={{ fontSize: 12 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 12 }} tickLine={false} axisLine={false} width={50} />
                <Tooltip formatter={(v: number) => [`${settings.currencySymbol}${v.toFixed(0)}`, 'Cost']} />
                <Bar dataKey="cost" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* kWh Over Time */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Energy Consumption (kWh)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthlySummary}>
                <XAxis dataKey="month" tick={{ fontSize: 12 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 12 }} tickLine={false} axisLine={false} width={50} />
                <Tooltip formatter={(v: number) => [`${v.toFixed(1)} kWh`, 'Energy']} />
                <Line type="monotone" dataKey="kWh" stroke="hsl(var(--chart-2))" strokeWidth={2} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Home vs Public Comparison */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Home vs Public Charging</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={costComparison}>
                <XAxis dataKey="type" tick={{ fontSize: 12 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 12 }} tickLine={false} axisLine={false} width={50} />
                <Tooltip />
                <Legend />
                <Bar dataKey="cost" name={`Cost (${settings.currencySymbol})`} fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
                <Bar dataKey="kWh" name="kWh" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
            {costComparison.map(d => (
              <div key={d.type} className="rounded-md border p-3 space-y-1">
                <p className="font-medium text-foreground">{d.type}</p>
                <p className="text-muted-foreground">{d.sessions} sessions</p>
                <p className="text-muted-foreground">Avg {settings.currencySymbol}{d.avgRate}/kWh</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        {/* Location Split */}
        {locationData.length > 0 && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Spending by Location</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={locationData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} label={({ name, value }) => `${name}: ${settings.currencySymbol}${value}`}>
                      {locationData.map((_, i) => (
                        <Cell key={i} fill={COLORS[i % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(v: number) => [`${settings.currencySymbol}${v}`, 'Cost']} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Vehicle Comparison */}
        {vehicleComparison.length > 1 && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Vehicle Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={vehicleComparison} layout="vertical">
                    <XAxis type="number" tick={{ fontSize: 12 }} tickLine={false} axisLine={false} />
                    <YAxis type="category" dataKey="name" tick={{ fontSize: 12 }} tickLine={false} axisLine={false} width={80} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="cost" name={`Cost (${settings.currencySymbol})`} fill="hsl(var(--chart-1))" radius={[0, 4, 4, 0]} />
                    <Bar dataKey="kWh" name="kWh" fill="hsl(var(--chart-2))" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Reports;
