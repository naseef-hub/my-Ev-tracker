import { Trip, Vehicle } from '@/types';

/**
 * Energy used on a trip: manual kWh entry wins, otherwise derive it from
 * the battery percentage drop and the vehicle's battery capacity.
 * Returns null when the trip has no usable energy data.
 */
export function tripEnergy(trip: Trip, vehicle?: Vehicle): number | null {
  if (trip.energyUsed && trip.energyUsed > 0) return trip.energyUsed;
  if (
    vehicle &&
    vehicle.batteryCapacity > 0 &&
    trip.batteryStart != null &&
    trip.batteryEnd != null &&
    trip.batteryStart > trip.batteryEnd
  ) {
    return ((trip.batteryStart - trip.batteryEnd) / 100) * vehicle.batteryCapacity;
  }
  return null;
}

export interface FleetEfficiency {
  kmPerUnit: number; // distance per kWh
  kmPerKWh: number; // alias kept for display code
  distance: number;
  energy: number;
  tripCount: number;
}

/**
 * Real efficiency from recorded trips (odometer distance vs energy used),
 * optionally for one vehicle. Returns null when no trip has both distance and energy.
 */
export function fleetEfficiency(
  trips: Trip[],
  vehicles: Vehicle[],
  vehicleId?: string
): FleetEfficiency | null {
  let distance = 0;
  let energy = 0;
  let tripCount = 0;
  for (const t of trips) {
    if (vehicleId && t.vehicleId !== vehicleId) continue;
    const vehicle = vehicles.find(v => v.id === t.vehicleId);
    const used = tripEnergy(t, vehicle);
    const dist = t.odometerEnd - t.odometerStart;
    if (!used || dist <= 0) continue;
    distance += dist;
    energy += used;
    tripCount += 1;
  }
  if (distance <= 0 || energy <= 0 || tripCount === 0) return null;
  const kmPerUnit = distance / energy;
  return { kmPerUnit, kmPerKWh: kmPerUnit, distance, energy, tripCount };
}
