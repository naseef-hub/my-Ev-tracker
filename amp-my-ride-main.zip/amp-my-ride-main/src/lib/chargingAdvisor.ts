import { ChargingSession, Settings, StationRate, Vehicle } from '@/types';

export interface StationStat {
  name: string;
  type: 'home' | 'public';
  sessions: number;
  totalKWh: number;
  totalCost: number;
  avgRate: number;
  lastUsed: string;
  /** true when the price comes from a real receipt or a price you confirmed for this station */
  confirmedRate?: boolean;
}


export interface TimeSlotStat {
  label: string;
  sessions: number;
  avgRate: number;
  totalKWh: number;
}

export interface AdvisorInsight {
  title: string;
  detail: string;
  saving?: number;
  tone: 'good' | 'warn' | 'info';
}

export interface AdvisorReport {
  hasData: boolean;
  totalSessions: number;
  totalKWh: number;
  totalCost: number;
  avgRate: number;
  homeKWh: number;
  publicKWh: number;
  homeCost: number;
  publicCost: number;
  homeAvgRate: number;
  publicAvgRate: number;
  stations: StationStat[];
  cheapestPublic?: StationStat;
  costliestPublic?: StationStat;
  bestSlots: TimeSlotStat[];
  monthly: { month: string; cost: number; kWh: number }[];
  insights: AdvisorInsight[];
  potentialMonthlySaving: number;
}

const rate = (s: ChargingSession) => (s.kWh > 0 ? s.cost / s.kWh : 0);

const slotLabel = (hour: number) => {
  if (hour < 6) return 'Late night (12am–6am)';
  if (hour < 12) return 'Morning (6am–12pm)';
  if (hour < 17) return 'Afternoon (12pm–5pm)';
  if (hour < 21) return 'Evening (5pm–9pm)';
  return 'Night (9pm–12am)';
};

export function buildAdvisorReport(
  sessions: ChargingSession[],
  settings: Settings,
  _vehicles: Vehicle[],
  stationRates: StationRate[] = []
): AdvisorReport {

  const valid = sessions.filter(s => s.kWh > 0);
  const empty: AdvisorReport = {
    hasData: false,
    totalSessions: 0,
    totalKWh: 0,
    totalCost: 0,
    avgRate: 0,
    homeKWh: 0,
    publicKWh: 0,
    homeCost: 0,
    publicCost: 0,
    homeAvgRate: settings.electricityRate,
    publicAvgRate: settings.publicChargingRate,
    stations: [],
    bestSlots: [],
    monthly: [],
    insights: [],
    potentialMonthlySaving: 0,
  };
  if (valid.length === 0) return empty;

  const totalKWh = valid.reduce((a, s) => a + s.kWh, 0);
  const totalCost = valid.reduce((a, s) => a + s.cost, 0);

  const home = valid.filter(s => s.locationType === 'home');
  const pub = valid.filter(s => s.locationType === 'public');
  const homeKWh = home.reduce((a, s) => a + s.kWh, 0);
  const publicKWh = pub.reduce((a, s) => a + s.kWh, 0);
  const homeCost = home.reduce((a, s) => a + s.cost, 0);
  const publicCost = pub.reduce((a, s) => a + s.cost, 0);
  const homeAvgRate = homeKWh > 0 ? homeCost / homeKWh : settings.electricityRate;
  const savedAvg = stationRates.length
    ? stationRates.reduce((a, r) => a + r.rate, 0) / stationRates.length
    : undefined;
  const publicAvgRate = publicKWh > 0 ? publicCost / publicKWh : (savedAvg ?? settings.publicChargingRate);


  // Stations
  const map = new Map<string, StationStat>();
  for (const s of valid) {
    const name = (s.location || (s.locationType === 'home' ? 'Home' : 'Public station')).trim();
    const key = `${s.locationType}::${name.toLowerCase()}`;
    const cur = map.get(key) ?? {
      name,
      type: s.locationType,
      sessions: 0,
      totalKWh: 0,
      totalCost: 0,
      avgRate: 0,
      lastUsed: s.date,
    };
    cur.sessions += 1;
    cur.totalKWh += s.kWh;
    cur.totalCost += s.cost;
    if (s.date > cur.lastUsed) cur.lastUsed = s.date;
    map.set(key, cur);
  }
  const savedRate = new Map(stationRates.map(r => [r.name.trim().toLowerCase(), r.rate]));
  // Known stations you have priced but not yet charged at
  for (const r of stationRates) {
    const key = `public::${r.name.trim().toLowerCase()}`;
    if (map.has(key)) continue;
    map.set(key, {
      name: r.name.trim(),
      type: 'public',
      sessions: 0,
      totalKWh: 0,
      totalCost: 0,
      avgRate: r.rate,
      lastUsed: r.updatedAt,
      confirmedRate: true,
    });
  }
  const stations = [...map.values()].map(st => {
    const saved = savedRate.get(st.name.trim().toLowerCase());
    const measured = st.totalKWh > 0 ? st.totalCost / st.totalKWh : undefined;
    return {
      ...st,
      avgRate: measured ?? saved ?? st.avgRate,
      confirmedRate: st.type === 'home' ? measured !== undefined : measured !== undefined || saved !== undefined,
    };
  });
  stations.sort((a, b) => a.avgRate - b.avgRate);


  const publicStations = stations.filter(s => s.type === 'public' && s.totalKWh > 0);
  const cheapestPublic = publicStations[0];
  const costliestPublic = publicStations[publicStations.length - 1];

  // Time slots (public charging only — that's where price varies)
  const slotMap = new Map<string, { sessions: number; kWh: number; cost: number }>();
  for (const s of valid) {
    const label = slotLabel(new Date(s.date).getHours());
    const cur = slotMap.get(label) ?? { sessions: 0, kWh: 0, cost: 0 };
    cur.sessions += 1;
    cur.kWh += s.kWh;
    cur.cost += s.cost;
    slotMap.set(label, cur);
  }
  const bestSlots = [...slotMap.entries()]
    .map(([label, v]) => ({
      label,
      sessions: v.sessions,
      totalKWh: v.kWh,
      avgRate: v.kWh > 0 ? v.cost / v.kWh : 0,
    }))
    .sort((a, b) => a.avgRate - b.avgRate);

  // Monthly
  const monthMap = new Map<string, { cost: number; kWh: number }>();
  for (const s of valid) {
    const d = new Date(s.date);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const cur = monthMap.get(key) ?? { cost: 0, kWh: 0 };
    cur.cost += s.cost;
    cur.kWh += s.kWh;
    monthMap.set(key, cur);
  }
  const monthly = [...monthMap.entries()]
    .sort((a, b) => (a[0] < b[0] ? -1 : 1))
    .map(([month, v]) => ({ month, ...v }));

  const months = Math.max(1, monthly.length);

  // Insights
  const insights: AdvisorInsight[] = [];
  let potentialSaving = 0;

  if (publicKWh > 0 && homeAvgRate < publicAvgRate) {
    const shift = publicKWh * 0.5 * (publicAvgRate - homeAvgRate);
    potentialSaving += shift;
    insights.push({
      tone: 'warn',
      title: 'Move half of your public charging home',
      detail: `You bought ${publicKWh.toFixed(1)} kWh publicly at an average of ${settings.currencySymbol}${publicAvgRate.toFixed(2)}/kWh versus ${settings.currencySymbol}${homeAvgRate.toFixed(2)}/kWh at home. Charging overnight at home for half of that would save about ${settings.currencySymbol}${shift.toFixed(0)}.`,
      saving: shift,
    });
  }

  if (cheapestPublic && costliestPublic && cheapestPublic.name !== costliestPublic.name) {
    const diff = costliestPublic.avgRate - cheapestPublic.avgRate;
    const save = costliestPublic.totalKWh * diff;
    if (save > 0) {
      potentialSaving += save;
      insights.push({
        tone: 'info',
        title: `Prefer ${cheapestPublic.name} over ${costliestPublic.name}`,
        detail: `${cheapestPublic.name} charges ${settings.currencySymbol}${cheapestPublic.avgRate.toFixed(2)}/kWh while ${costliestPublic.name} charges ${settings.currencySymbol}${costliestPublic.avgRate.toFixed(2)}/kWh. Switching the ${costliestPublic.totalKWh.toFixed(1)} kWh you took at the pricier station would have saved ${settings.currencySymbol}${save.toFixed(0)}.`,
        saving: save,
      });
    }
  }

  if (bestSlots.length > 1) {
    const best = bestSlots[0];
    const worst = bestSlots[bestSlots.length - 1];
    if (worst.avgRate - best.avgRate > 0.01) {
      insights.push({
        tone: 'info',
        title: `Charge during ${best.label}`,
        detail: `Your cheapest charging happens in the ${best.label.toLowerCase()} at ${settings.currencySymbol}${best.avgRate.toFixed(2)}/kWh, versus ${settings.currencySymbol}${worst.avgRate.toFixed(2)}/kWh in the ${worst.label.toLowerCase()}.`,
      });
    }
  }

  if (homeKWh > 0 && publicKWh >= 0) {
    const homeShare = (homeKWh / totalKWh) * 100;
    insights.push({
      tone: homeShare >= 70 ? 'good' : 'info',
      title: `${homeShare.toFixed(0)}% of your energy comes from home charging`,
      detail:
        homeShare >= 70
          ? 'Great habit — home charging is your cheapest source and you are already using it for most of your energy.'
          : 'Raising this share is the single biggest lever on your charging bill.',
    });
  }

  return {
    hasData: true,
    totalSessions: valid.length,
    totalKWh,
    totalCost,
    avgRate: totalKWh > 0 ? totalCost / totalKWh : 0,
    homeKWh,
    publicKWh,
    homeCost,
    publicCost,
    homeAvgRate,
    publicAvgRate,
    stations,
    cheapestPublic,
    costliestPublic,
    bestSlots,
    monthly,
    insights,
    potentialMonthlySaving: potentialSaving / months,
  };
}
