const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      return new Response(JSON.stringify({ error: "AI is not configured." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { messages, snapshot } = await req.json();

    const systemPrompt = `You are the EV Charging Assistant inside a personal EV expense tracker app.
You help the owner understand their charging costs, energy use, mileage/efficiency and savings.
Use ONLY the data snapshot below. Be concise, practical and friendly. Use the currency symbol given.
Show short bullet points and real numbers. If data is missing, say what the user should log.

DATA SNAPSHOT (JSON):
${JSON.stringify(snapshot ?? {})}`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Lovable-API-Key": LOVABLE_API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3.7-flash",
        stream: true,
        messages: [{ role: "system", content: systemPrompt }, ...(messages ?? [])],
      }),
    });

    if (!response.ok) {
      const text = await response.text();
      let message = "The assistant is unavailable right now.";
      if (response.status === 429) message = "Too many requests. Please try again in a moment.";
      if (response.status === 402) message = "AI credits are exhausted. Please top up to keep using the assistant.";
      console.error("gateway error", response.status, text);
      return new Response(JSON.stringify({ error: message }), {
        status: response.status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: {
        ...corsHeaders,
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: "Unexpected error." }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
