

# EV Charging Expense & Power Consumption Tracker

## Overview
A responsive web app (PWA) to track EV charging sessions, costs, and energy consumption across multiple vehicles — all data stored locally on your device using browser localStorage.

---

## Pages & Features

### 1. Dashboard
- Quick stats: total spend this month, total kWh, average cost per km
- Recent charging sessions at a glance
- Mini chart showing spending trend (last 7 days or 30 days)
- Quick "Add Session" button

### 2. Add/Edit Charging Session
- Form to log a charging session with:
  - Select vehicle
  - Date & time
  - kWh consumed
  - Cost (₹/$)
  - Charging location (home / public station name)
  - Odometer reading
- Auto-calculate cost per kWh

### 3. Vehicle Management
- Add, edit, and delete EVs
- Vehicle name, make/model, battery capacity
- Per-vehicle stats summary

### 4. Charging History
- Searchable, filterable table/list of all sessions
- Filter by vehicle, date range, location
- Sort by date, cost, kWh
- Export data option (CSV download)

### 5. Reports & Analytics
- Monthly summary with total cost, kWh, and number of sessions
- Cost per km/mile trend chart
- Spending by location (home vs. public) bar chart
- kWh consumption over time line chart
- Vehicle comparison (if multiple EVs)

### 6. Settings
- Currency preference (₹, $, €, etc.)
- Distance unit (km / miles)
- Electricity rate (for home charging cost estimation)
- Data backup: export/import JSON for backup & restore

---

## Technical Approach
- **Local Storage**: All data stored in browser localStorage — no account or internet needed
- **PWA**: Installable on phone home screen, works offline
- **Responsive Design**: Works great on both desktop and mobile
- **Charts**: Interactive charts using Recharts (already installed)

---

## Design
- Clean, modern dashboard with card-based layout
- Dark/light mode support
- Mobile-first responsive design with bottom navigation on mobile

